#!/usr/bin/env python3
"""Controlli esatti, su casi piccoli, delle identità usate nel teorema condizionale.

1. Identità del modello: per ogni k,
       sum_{H in [1,y], |H|=k} M(H) = E[ 1_tw * binom(S, k) ],
   dove M(H) è il prodotto delle densità locali (taglio Z1 per n, n+2 e
   taglio Z2 per le forme 2n+h) ed E è la media su n modulo il prodotto
   dei primi <= Z2.
2. Disuguaglianza di Bonferroni troncata: per K dispari e ogni m >= 0,
       delta_K(m) >= delta(m) - binom(m, K+1).
3. Accoppiamento per i primi grandi: se le classi sono uniformi su Z/p
   privato di {0, 4}, la probabilità di coprire un insieme R di elementi
   dispari in [1, y] (p > y) non è minore che con classi uniformi su Z/p.
4. Media dei sopravvissuti per i primi medi con classi condizionate:
       E[S] = sum_{h in J} prod_p (1 - [h != 0, 4 mod p] / (p - 2)).

Tutti i confronti usano frazioni esatte. Uso: python verifica_teorema_condizionale.py
"""

import hashlib
import itertools
import json
import math
from fractions import Fraction
from pathlib import Path


def primes_upto(n):
    return [p for p in range(2, n + 1) if all(p % d for d in range(2, math.isqrt(p) + 1))]


def nu_twin(H, p):
    """#{m mod p : p | m (m+2) prod_{h in H} (2m+h)}."""
    return sum(1 for m in range(p) if m % p == 0 or (m + 2) % p == 0 or any((2 * m + h) % p == 0 for h in H))


def nu_window(H, p):
    """#{m mod p : p | prod_{h in H} (2m+h)}."""
    return sum(1 for m in range(p) if any((2 * m + h) % p == 0 for h in H))


def check_model_identity(Z1, Z2, y, kmax):
    P1 = [p for p in primes_upto(Z2) if p <= Z1]
    P2 = [p for p in primes_upto(Z2) if p > Z1]
    modulus = math.prod(P1 + P2)
    counts = {}
    for n in range(modulus):
        if any(n % p == 0 or (n + 2) % p == 0 for p in P1):
            continue
        s = sum(1 for h in range(1, y + 1) if all((2 * n + h) % p for p in P1 + P2))
        counts[s] = counts.get(s, 0) + 1
    rows = []
    for k in range(kmax + 1):
        rhs = Fraction(sum(c * math.comb(s, k) for s, c in counts.items()), modulus)
        lhs = Fraction(0)
        for H in itertools.combinations(range(1, y + 1), k):
            term = Fraction(1)
            for p in P1:
                term *= Fraction(p - nu_twin(H, p), p)
            for p in P2:
                term *= Fraction(p - nu_window(H, p), p)
            lhs += term
        rows.append({"k": k, "somma_M": str(lhs), "media_modello": str(rhs), "uguali": lhs == rhs})
    return {"Z1": Z1, "Z2": Z2, "y": y, "modulo": modulus, "righe": rows}


def check_bonferroni(Kmax, mmax):
    bad = []
    for K in range(1, Kmax + 1, 2):
        for m in range(mmax + 1):
            dK = sum((-1) ** k * math.comb(m, k) for k in range(K + 1))
            d = 1 if m == 0 else 0
            if dK < d - math.comb(m, K + 1):
                bad.append((K, m))
    return {"K_dispari_fino_a": Kmax, "m_fino_a": mmax, "violazioni": bad}


def cover_probability(s, primes, conditioned):
    """P(all s elements, in distinct classes different from 0 and 4, are hit)."""
    total = Fraction(0)
    for i in range(s + 1):
        prod = Fraction(1)
        for p in primes:
            q = p - 2 if p in conditioned else p
            prod *= Fraction(q - i, q)
        total += (-1) ** i * math.comb(s, i) * prod
    return total


def check_coupling(y):
    primes = [p for p in primes_upto(400) if p > y]
    rows = []
    for s in (1, 2, 3, 5, 8):
        cond = set(primes[: len(primes) // 2])
        pu = cover_probability(s, primes, set())
        pc = cover_probability(s, primes, cond)
        theta = math.prod(1 - 1 / p for p in primes)
        rows.append({"s": s, "P_uniforme": float(pu), "P_condizionata": float(pc), "condizionata_maggiore": pc >= pu,
                     "(1-Theta)^s": (1 - theta) ** s})
    # brute-force confirmation on a tiny instance: R = {1, 3}, primes 7, 11 (> y = 5), first one conditioned
    R, ps, y_small = [1, 3], [7, 11], 5
    def brute(conditioned):
        tot = Fraction(0)
        choices = [[c for c in range(p) if not (p in conditioned and c in (0, 4 % p))] for p in ps]
        for combo in itertools.product(*choices):
            if all(any(c == r % p for c, p in zip(combo, ps)) for r in R):
                tot += Fraction(1, math.prod(len(ch) for ch in choices))
        return tot
    rows.append({"forza_bruta_R=[1,3]_primi=[7,11]": {"uniforme": str(brute(set())), "condizionata_su_7": str(brute({7})),
                                                         "formula_uniforme": str(cover_probability(2, ps, set())),
                                                         "formula_condizionata": str(cover_probability(2, ps, {7}))}})
    return {"y": y, "righe": rows}


def check_medium_expectation(y, z1, medium):
    small = [p for p in primes_upto(z1)]
    # class G pattern: positions h odd, h != 2 mod 3, h != 1 mod p (5 <= p <= z1)
    J = [h for h in range(1, y + 1) if h % 2 == 1 and h % 3 != 2 and all((h - 1) % p for p in small if p >= 5)]
    choices = [[c for c in range(p) if c not in (0, 4 % p)] for p in medium]
    total, count = Fraction(0), 0
    for combo in itertools.product(*choices):
        total += sum(1 for h in J if all(h % p != c for c, p in zip(combo, medium)))
        count += 1
    exact = total / count
    formula = Fraction(0)
    for h in J:
        term = Fraction(1)
        for p in medium:
            if h % p not in (0, 4 % p):
                term *= Fraction(p - 3, p - 2)
        formula += term
    return {"y": y, "z1": z1, "primi_medi": medium, "|J|": len(J), "media_esatta": str(exact),
            "formula": str(formula), "uguali": exact == formula}


def main():
    out = {
        "1_identita_modello": check_model_identity(Z1=11, Z2=13, y=12, kmax=5),
        "2_bonferroni": check_bonferroni(Kmax=41, mmax=300),
        "3_accoppiamento": check_coupling(y=20),
        "4_media_primi_medi": check_medium_expectation(y=60, z1=5, medium=[7, 11, 13]),
        "sha256_script": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    ok = (all(r["uguali"] for r in out["1_identita_modello"]["righe"])
          and not out["2_bonferroni"]["violazioni"]
          and all(r.get("condizionata_maggiore", True) for r in out["3_accoppiamento"]["righe"])
          and out["4_media_primi_medi"]["uguali"])
    out["tutti_i_controlli_superati"] = ok
    Path("verifica_teorema_condizionale.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({k: v for k, v in out.items() if k != "sha256_script"}, indent=1, ensure_ascii=False)[:6000])


if __name__ == "__main__":
    main()
