"""Deduce una verifica finita della congettura dai gap esaustivi pubblicati.

Fonte: Oliveira e Silva, Herzog, Pardi, Math. Comp. 83 (2014).
La completezza della loro scansione resta un input esterno pubblicato; questo
programma verifica esattamente la riduzione, i logaritmi e il primo di confine.
Nessuna congettura sui gap viene assunta.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import math
import random
import re
from collections import Counter
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path


RNG = random.Random(20261025)
CERTIFICATES = {}


def screening(n):
    """Filtro per trovare fattori; la certificazione finale NON si basa su questo."""
    if n < 2:
        return False
    for p in (2,3,5,7,11,13,17,19,23,29,31,37):
        if n%p == 0:
            return n == p
    d=n-1
    s=0
    while d%2 == 0:
        d//=2
        s+=1
    for a in (2,325,9375,28178,450775,9780504,1795265022):
        if a%n == 0:
            continue
        x=pow(a,d,n)
        if x in (1,n-1):
            continue
        for _ in range(s-1):
            x=x*x%n
            if x == n-1:
                break
        else:
            return False
    return True


def rho(n):
    if n%2 == 0:
        return 2
    if n%3 == 0:
        return 3
    while True:
        y,c=RNG.randrange(1,n),RNG.randrange(1,n)
        g,r=1,1
        while g==1 and r<=2**21:
            x=y
            for _ in range(r):
                y=(y*y+c)%n
            k=0
            while k<r and g==1:
                ys=y
                product=1
                for _ in range(min(128,r-k)):
                    y=(y*y+c)%n
                    product=product*abs(x-y)%n
                g=math.gcd(product,n)
                k+=128
            r*=2
        if g==n:
            while True:
                ys=(ys*ys+c)%n
                g=math.gcd(abs(x-ys),n)
                if g>1:
                    break
        if 1<g<n:
            return g


def factors(n):
    if n==1:
        return []
    if screening(n):
        return [n]
    divisor=rho(n)
    assert 1<divisor<n and n%divisor==0
    return factors(divisor)+factors(n//divisor)


def make_certificate(n):
    key=str(n)
    if key in CERTIFICATES:
        return
    if n==2:
        CERTIFICATES[key]={"n":"2","method":"base"}
        return
    fs=Counter(factors(n-1))
    for q in fs:
        make_certificate(q)
    for witness in range(2,10001):
        if pow(witness,n-1,n)==1 and all(math.gcd(pow(witness,(n-1)//q,n)-1,n)==1 for q in fs):
            CERTIFICATES[key]={"n":key,"method":"Lucas_full_factorization",
                "factors_n_minus_1":[{"q":str(q),"exponent":exponent} for q,exponent in sorted(fs.items())],
                "witness":witness}
            return
    raise RuntimeError(f"Nessun certificato trovato per {n}.")


def verify_certificate(n, certificates, checked=None):
    """Solo aritmetica intera: non usa alcun test di probabile primalita."""
    if checked is None:
        checked=set()
    if n in checked:
        return
    item=certificates[str(n)]
    if n==2:
        assert item["method"]=="base"
        checked.add(n)
        return
    assert n>2 and n%2==1
    fs=item["factors_n_minus_1"]
    assert fs and len({int(row["q"]) for row in fs})==len(fs)
    product=1
    for row in fs:
        q=int(row["q"])
        exponent=int(row["exponent"])
        assert 2<=q<n and exponent>=1
        verify_certificate(q,certificates,checked)
        product*=q**exponent
    assert product==n-1
    a=int(item["witness"])
    assert pow(a,n-1,n)==1
    for row in fs:
        q=int(row["q"])
        assert math.gcd(pow(a,(n-1)//q,n)-1,n)==1
    checked.add(n)


def log2_lower():
    # log 2 = 2 atanh(1/3), serie con tutti i termini positivi.
    return 2*sum((Fraction(1,(2*j+1)*3**(2*j+1)) for j in range(32)),Fraction(0))


def log_lower(n, lower2):
    exponent=n.bit_length()-1
    lower=exponent*lower2
    power=1<<exponent
    z=Fraction(n-power,n+power)
    lower+=2*sum((z**(2*j+1)/Fraction(2*j+1) for j in range(8)),Fraction(0))
    return lower


def main():
    source=Path("fonti_esterne/oliveira_prime_gaps_t0.txt.gz")
    raw=source.read_bytes()
    contents=gzip.decompress(raw).decode("utf-8")
    assert "# Test interval ---------- [2,4d18]" in contents
    rows=[]
    for line in contents.splitlines():
        match=re.match(r"^\s*(\d+)(\*?)\s+(\d+)(\*?)\s+(\d+)\b",line)
        if match:
            rows.append({"gap":int(match[1]),"first_prime":int(match[3]),"count":int(match[5])})
    assert len({row["gap"] for row in rows})==len(rows)
    assert rows and all(row["count"]>0 for row in rows)
    B=4*10**18
    last_prime=2+sum(row["gap"]*row["count"] for row in rows)
    assert last_prime<B
    print("Primo finale ricostruito per telescopaggio:",last_prime,flush=True)
    make_certificate(last_prime)
    verify_certificate(last_prime,CERTIFICATES)
    print("Certificato di Lucas del primo finale verificato; nodi:",len(CERTIFICATES),flush=True)

    lower2=log2_lower()
    checks=[]
    minimum=None
    for row in rows:
        p,g=row["first_prime"],row["gap"]
        assert 2<=p<p+g<=last_prime
        exponent=p.bit_length()-1
        lower=exponent*lower2
        method="floor_log2"
        if lower*lower<=g-1:
            lower=log_lower(p,lower2)
            method="atanh_ratio"
        margin=lower*lower-(g-1)
        assert margin>0
        if minimum is None or margin<minimum[0]:
            minimum=(margin,p,g)
        checks.append(dict(row,certificate_method=method))

    D=max(row["gap"] for row in rows)
    for _ in range(20):
        p_bound=(last_prime-1)//D
        new_D=max(row["gap"] for row in rows if row["first_prime"]<=p_bound)
        if new_D==D:
            break
        D=new_D
    else:
        raise RuntimeError("Limite uniforme non stabilizzato.")
    assert 2*p_bound<B  # Bertrand garantisce che anche p2 cada nella scansione.
    assert D*p_bound<last_prime
    first_larger=min((row["first_prime"],row["gap"]) for row in rows if row["gap"]>D)
    assert first_larger[0]>p_bound
    with localcontext() as ctx:
        ctx.prec=50
        displayed_margin=str(Decimal(minimum[0].numerator)/Decimal(minimum[0].denominator))
    result={
        "date":"2026-10-25",
        "source_url":"https://sweet.ua.pt/tos/gaps/t0.txt.gz",
        "source_description":"Oliveira e Silva, Herzog, Pardi, Math. Comp. 83 (2014), exhaustive gaps to 4e18",
        "source_sha256":hashlib.sha256(raw).hexdigest(),
        "external_input":"Completeness of published exhaustive gap scan; not rerun in this session.",
        "scan_limit":B,"distinct_observed_gaps":len(rows),"gap_count":sum(row["count"] for row in rows),
        "last_prime_from_telescoping":last_prime,"distance_from_scan_limit":B-last_prime,
        "generic_M_bound_inclusive":last_prime-1,
        "uniform_p1_bound_inclusive":p_bound,"gap_bound_for_uniform_p1":D,
        "max_M_for_uniform_p1":D*p_bound,
        "first_larger_gap_start":first_larger[0],"first_larger_gap":first_larger[1],
        "gap_dependent_p1_bounds":[{"d":d,"p1_bound":(last_prime-1)//d} for d in (2,4,6,8,10,12,30,60,100,1132)],
        "log_certificate":"Exact positive rational series lower bounds for log: lower(log p)^2 > gap-1.",
        "atanh_extra_cases":[row for row in checks if row["certificate_method"]!="floor_log2"],
        "minimum_proved_log_margin":{"p":minimum[1],"gap":minimum[2],"decimal_display_only":displayed_margin},
        "primality_certificates":CERTIFICATES,
        "all_gap_checks":checks,
        "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    output=Path("certificato_estensione_finita.json")
    output.write_text(json.dumps(result,indent=2),encoding="utf-8")
    # Rilegge il certificato serializzato e ne ripete la verifica indipendente.
    saved=json.loads(output.read_text(encoding="utf-8"))
    verify_certificate(saved["last_prime_from_telescoping"],saved["primality_certificates"])
    print(json.dumps({key:value for key,value in result.items() if key not in ("primality_certificates","all_gap_checks")},indent=2))


if __name__=="__main__":
    main()
