# Congettura Sparacino: verifica critica e lemmi aritmetici

Data dell'analisi: 25 ottobre 2026.

Fonte esaminata: [Zenodo, record 21973485](https://zenodo.org/records/21973485), versione della pagina v12, pubblicata il 17 agosto 2026. L'unico allegato si chiama `Sparacino_Conjecture_v11.pdf`, ma il testo interno si identifica come v9. Il PDF è stato letto integralmente attraverso l'anteprima di Zenodo. I metadati sono conservati in `zenodo-record-21973485.json`.

Il [repository originale](https://github.com/xxrickyxx/Sparacino-Conjecture-2026-on-Primes-After-the-Product-of-Consecutive-Prime-Gap-and-1-p-1-) è stato scaricato in `fonti_originali`, commit `ee3e8732591d73836f65432b8847345556c98fdb`. I programmi originali non sono stati eseguiti. Per il file NPZ originale sono stati letti soltanto array numerici, con `allow_pickle=False`.

## 1. Enunciato e stato logico

Per due primi consecutivi p < p₂, siano d = p₂ − p, M = dp e N = ceil((log M)²), con logaritmo naturale. Si cerca un primo r con M < r ≤ M + N.

Questa analisi non dimostra né confuta l'enunciato universale. Dimostra invece alcuni lemmi, riproduce controlli numerici esatti in un intervallo dichiarato e individua errori specifici nella descrizione pubblicata. Il PDF conclude correttamente che la dimostrazione è aperta; la descrizione della pagina contiene invece un argomento BHP non valido.

## 2. Lemma: il primo candidato evita i fattori di tre interi consecutivi

**Proposizione.** Se p > 2 e p₂ = p + d è primo, con d > 1, allora

\[
\gcd(dp+1,\ d(d-1)(d+1))=1.
\]

Non serve assumere che i due primi siano consecutivi.

**Dimostrazione.** Il numero dp + 1 è coprimo con d. Inoltre

\[
dp+1=d p_2-(d^2-1).
\]

Un primo q comune a dp + 1 e d² − 1 dividerebbe d p₂. Poiché q non divide d, sarebbe q = p₂. Ma p₂ non può dividere (d − 1)(d + 1): è primo ed è maggiore di entrambi i fattori positivi, perché p₂ = p + d > d + 1. Contraddizione.

Conseguenze concrete:

| Gap d | Primi che non possono dividere M + 1 |
|---:|---|
| 2 | 2, 3 |
| 4 | 2, 3, 5 |
| 6 | 2, 3, 5, 7 |
| 10 | 2, 3, 5, 11 |
| 12 | 2, 3, 11, 13 |

Per ogni coppia con p > 2, M + 1 è dunque coprimo con 6. Se 3 divide d è immediato; altrimenti 3 divide d² − 1 e interviene il lemma.

Il lemma spiega un vantaggio aritmetico del candidato k = 1 e suggerisce di includere d − 1 e d + 1 nell'analisi. Non garantisce la primalità: p = 109, p₂ = 113, d = 4 dà M + 1 = 437 = 19 × 23.

### Estensione ai quadrati

Se 1 ≤ t < p e gcd(t,d) = 1, allora

\[
\gcd(dp+t^2,\ d\,|d-t|\,(d+t))=1.
\]

Infatti dp + t² = d p₂ − (d² − t²). Un primo comune al candidato e a d² − t², non potendo dividere d, dovrebbe essere p₂. Ma entrambi i fattori |d − t| e d + t sono minori di p₂. Il caso d = t è escluso da gcd(t,d) = 1 e d > 1.

Se invece gcd(t,d) > 1, il candidato dp + t² è composto, perché ha un divisore comune non banale con d ed è maggiore di d.

Nel controllo indipendente il lemma è stato anche verificato su 2.584.793 combinazioni ammissibili di coppia e t, per t = 1, 3, 5, 7, 9. La sua validità generale deriva dalla dimostrazione, non dal conteggio.

## 3. Un modello locale più preciso del solo C(d)

Fissiamo un primo q < p. Per q che non divide d, i vincoli che p e p + d non siano divisibili per q escludono i residui p ≡ 0 e p ≡ −d. Restano q − 2 residui. La divisibilità di dp + k per q esclude inoltre p ≡ −k/d.

Il conteggio esatto dei residui è quindi:

| Condizione | Frazione dei residui ammessi dai due estremi che evita q nel candidato |
|---|---:|
| q divide d, q divide k | 0 |
| q divide d, q non divide k | 1 |
| q non divide d, k ≡ 0 oppure d² (mod q) | 1 |
| q non divide d, k diverso da 0 e d² (mod q) | (q − 3)/(q − 2) |

La tabella è un'identità combinatoria per residui uniformemente pesati. Usarla per probabilità empiriche richiede un'ipotesi di distribuzione; la consecutività introduce anche l'assenza di primi fra gli estremi. Moltiplicare fattori locali non dà una dimostrazione dell'esistenza di un primo.

In particolare, il prodotto C(d) = ∏_{q|d} q/(q−1) non rappresenta da solo un aumento della densità su tutti gli offset k. Se q divide M, nell'intervallo 1 ≤ k ≤ N ci sono esattamente floor(N/q) offset con q che divide M + k. Su un ciclo completo la proporzione resta 1/q. Un vantaggio condizionato su certi offset non va contato come vantaggio uniforme dell'intero intervallo.

## 4. Tre criticità verificabili nella pubblicazione

### 4.1 Il richiamo a Baker–Harman–Pintz non dimostra l'enunciato

Il risultato [Baker, Harman e Pintz, 2001](https://londmathsoc.onlinelibrary.wiley.com/doi/10.1112/plms/83.3.532) riguarda intervalli di lunghezza dell'ordine di x^0,525 per x sufficientemente grande. La descrizione Zenodo osserva che (log M)² è molto più piccolo di M^0,525 e ne deduce la presenza di un primo nell'intervallo più corto. L'implicazione è invertita: sapere che un insieme grande contiene un primo non dice che lo contenga un suo sottoinsieme.

Per esempio, a M = 10³⁰ le due lunghezze sono circa 4.772 e 5,62 × 10¹⁵. Anche una soglia BHP esplicita non risolverebbe questa differenza di scala. Inoltre campioni isolati fino a 10³⁰ non coprono tutti i valori intermedi.

### 4.2 Il limite configurato non è il limite completato

Il registro `fonti_originali/risultato_gpu_10000000000000.txt` riporta esplicitamente l'interruzione manuale e 139.864.010 coppie elaborate. Nel programma il valore 10¹³ è il limite richiesto, scritto nell'intestazione prima del calcolo.

Il crivello indipendente di questa analisi ha contato esattamente

\[
\pi(2.900.000.000)=139.864.011.
\]

Quindi il numero di coppie del registro coincide con π(2,9 × 10⁹) − 1. Considerata la scansione originale per blocchi di 50 milioni, questa è una ricostruzione coerente del punto raggiunto, non una verifica esaustiva fino a 10¹³. L'ultimo primo prima del confine è 2.899.999.957. Non sono state riverificate in questa sessione tutte le 139 milioni di risposte del vecchio programma.

Il valore 451 nel PDF è inoltre etichettato come massimo gap d. L'archivio e il report originale lo identificano come massimo offset k. I gap tra primi consecutivi sono pari, salvo il solo gap 1 fra 2 e 3: 451 non può essere un gap d in quel dataset.

### 4.3 Le 15 basi non certificano la primalità fino a 10³⁰

Il codice `fonti_originali/test_final.py` usa le prime 15 basi prime, da 2 a 47. Il suo commento interno è già più cauto della descrizione Zenodo. Esiste però un controesempio esplicito alla garanzia dichiarata:

\[
59\,276\,361\,075\,595\,573\,263\,446\,330\,101
=172\,157\,429\,516\,701\times344\,314\,859\,033\,401.
\]

Questo intero è minore di 10³⁰ ed è composto, ma supera tutti i 15 test forti di Miller–Rabin alle basi usate. La fattorizzazione e i test sono verificati con interi esatti da `audit_riproducibile.py`; non occorre assumere che i due fattori siano primi per certificare che il prodotto sia composto. Come contesto sul significato delle soglie per insiemi di basi, si veda [Sorenson e Webster](https://arxiv.org/abs/1509.00864).

Il numero non è stato identificato fra le effettive risposte del vecchio esperimento. È un controesempio alla garanzia del metodo, non alla congettura. Un falso positivo sugli estremi può anche far apparire consecutivi numeri che non costituiscono una coppia valida di primi. Per certificare le scale grandi occorrono limiti validi per le basi effettivamente usate oppure certificati di primalità, con gestione corretta degli estremi e degli interi interposti.

## 5. Verifica indipendente completata

Il programma `verifica_indipendente.py` genera esattamente i primi e cerca i primi successivi mediante crivelli di Eratostene segmentati. Non usa Miller–Rabin. Include anche il successore dell'ultimo primo sotto il limite.

| Misura | Risultato |
|---|---:|
| Limite inclusivo su p | 10.000.000 |
| Coppie consecutive verificate | 664.579 |
| Ultima coppia | 9.999.991; 10.000.019 |
| Massimo M | 1.280.030.152 |
| Massimo gap d | 154 |
| Controesempi alla congettura | 0 |
| Massimo offset k | 235 |
| Media di k su tutte le coppie | 14,410983 |
| Media di k/log M su tutte le coppie | 0,826992 |

Per tutte le coppie la disuguaglianza è stata certificata anche con un limite inferiore conservativo per ceil((log M)²), costruito con interi esatti e log 2 > 0,6931471805599453. Non è servito risolvere casi al confine tramite approssimazioni decimali. Il massimo assoluto k/N è 1 per la coppia iniziale (2,3).

**Un caso che corregge il massimo 0,414 dichiarato nella descrizione** è:

\[
p=1.005.371,\quad p_2=1.005.373,\quad d=2,\quad M=2.010.742;
\]
\[
N=211,\quad r=2.010.881,\quad k=139,\quad k/N=0,6587677725\ldots.
\]

Il primo arriva dentro la finestra prevista dalla congettura. In `certificati_audit.json` sono conservati un divisore per ogni M + k con 1 ≤ k < 139 e la verifica per divisione diretta della primalità degli estremi e di r. Sono stati inoltre ricontrollati per divisione diretta 120 casi del nuovo esperimento, comprendenti un campione con seme fissato e i 20 rapporti peggiori; per ogni caso sono state controllate sia la consecutività sia la minimalità dell'offset.

## 6. Il vantaggio medio dipende dal gruppo di confronto

Per le 586.081 coppie con 1.000.003 ≤ p ≤ 10⁷, sono stati confrontati M con punti vicini dello stesso ordine di grandezza:

| Punto iniziale | Distanza media dal primo successivo |
|---|---:|
| M = dp | 14,724669 |
| M + 2j, j uniforme intero in [1,10000] | 15,319792 |
| M + 30j, j uniforme intero in [1,667] | 14,658266 |

Seme del generatore: 20261025. Sono controlli finiti abbinati, con una traslazione positiva inferiore a circa 20.000; non sono un teorema statistico o una stima universale.

Il confronto con punti pari mostra qui una distanza media inferiore di circa il 3,88%. Preservando anche il residuo modulo 30, questo vantaggio non appare: la media a M è circa lo 0,45% maggiore. Questo suggerisce che occorra separare gli effetti dei residui piccoli da eventuali ulteriori regolarità. Un singolo seme e un intervallo finito non stabiliscono un'assenza universale di vantaggio.

## 7. Che cosa manca per una dimostrazione

I lemmi eliminano classi di divisori per determinati candidati; rimangono i possibili divisori non esclusi. Per dimostrare l'enunciato bisogna garantire uniformemente almeno un candidato primo nell'intervallo di lunghezza ceil((log M)²), non soltanto una media positiva o molti candidati senza fattori piccoli.

Una prosecuzione utile consiste nel confrontare frequenze e casi estremi condizionando per d, per i fattori di d − 1 e d + 1 e per il residuo di M modulo piccoli prodotti di primi. I quadrati t² con gcd(t,d) = 1 offrono una famiglia precisa da studiare. Ogni stima probabilistica andrà distinta da un limite inferiore uniforme dimostrato.

## 8. Riproducibilità e materiali

Sono presenti nella stessa cartella:

- `verifica_indipendente.py`: nuova verifica esatta e gruppi di confronto;
- `risultati_verifica_indipendente.json`: conteggi, estremi, statistiche e impronta dello script;
- `verifica_indipendente_coppie.npz`: tutte le nuove coppie, gli offset e i controlli, senza oggetti pickle;
- `statistiche_indipendenti_per_gap.csv`: statistiche separate per d;
- `audit_riproducibile.py`: controesempio al test a 15 basi e controlli per divisione diretta;
- `certificati_audit.json`: fattorizzazioni, test forti, certificati del caso con rapporto 0,659 e impronte delle fonti;
- `fonti_originali/`: copia del repository pubblico, mantenuta separata.

Esecuzione, con Python e NumPy disponibili:

```text
python verifica_indipendente.py --limit 10000000 --count-to 2900000000
python audit_riproducibile.py
```

La prima esecuzione misura anche π(2,9 × 10⁹), ma verifica la congettura soltanto per p ≤ 10⁷. Il massimo del crivello e il limite degli estremi p sono grandezze diverse e vengono riportati separatamente.
