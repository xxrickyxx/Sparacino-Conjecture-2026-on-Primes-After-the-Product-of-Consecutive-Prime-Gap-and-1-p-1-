# Una verifica finita derivata dai gap esaustivi pubblicati

25 ottobre 2026.

**Risultato:** dai dati esaustivi di Oliveira e Silva, Herzog e Pardi si deduce la congettura Sparacino per tutte le coppie consecutive con

\[
\boxed{p_1\leq 3\,533\,568\,904\,593\,639.}
\]

Più in generale, la stessa deduzione copre ogni coppia per cui

\[
\boxed{M=(p_2-p_1)p_1\leq3\,999\,999\,999\,999\,999\,886.}
\]

È una verifica finita che usa come input la scansione esaustiva pubblicata. Non è una dimostrazione per p₁ arbitrariamente grande. In questa sessione sono stati verificati la riduzione matematica, tutte le disuguaglianze necessarie sulla tabella e un certificato esatto del primo al confine; la scansione originale fino a 4 × 10¹⁸ è il lavoro degli autori citati.

## 1. Fonte e dati

T. Oliveira e Silva, S. Herzog e S. Pardi, *Empirical verification of the even Goldbach conjecture and computation of prime gaps up to 4·10¹⁸*, Mathematics of Computation 83 (2014), 2033–2060.

- [Scheda dell'articolo sul sito dell'autore](https://sweet.ua.pt/tos/bib/4.12.html).
- [Pagina dei gap e della copertura dichiarata](https://sweet.ua.pt/tos/gaps.html).
- [Tabella originale compressa](https://sweet.ua.pt/tos/gaps/t0.txt.gz).

La tabella dichiara la scansione [2,4 × 10¹⁸] e una seconda scansione di controllo fino a 4 × 10¹⁷. Il presente risultato usa la prima copertura, riportata anche nell'articolo pubblicato.

Per ciascuna lunghezza di gap osservata g, la tabella contiene P(g), il primo iniziale della sua prima occorrenza, e N(g), il numero di occorrenze nella scansione. Il conteggio usa gap con secondo estremo entro il limite.

La copia scaricata contiene 696 lunghezze di gap osservate, per un totale di 95.676.260.903.887.606 gap. Il suo SHA-256 è

```text
7227a85c31cbfc16e4bbd5588d4b3bb1a9c11e360d558745cc55e73b9f5d11b7
```

La completezza della tabella è un input computazionale esterno. I controlli locali di seguito non pretendono di ricostruire l'intera scansione.

## 2. Dalle prime occorrenze a tutti i gap coperti

Per ciascuna delle 696 righe è stata verificata esattamente la disuguaglianza

\[
g\leq\lceil(\log P(g))^2\rceil.
\]

Ogni successiva occorrenza della stessa lunghezza g ha primo iniziale a ≥ P(g). Per monotonia,

\[
g\leq\lceil(\log a)^2\rceil.
\]

Quindi la disuguaglianza vale per ogni gap incluso nella scansione, senza dover riesaminare singolarmente i suoi due estremi.

### Certificazione dei logaritmi senza arrotondamenti

Non è stato necessario affidarsi a valori floating point. Si usa la serie positiva

\[
\log 2=2\sum_{j=0}^{\infty}\frac{1}{(2j+1)3^{2j+1}}.
\]

La somma dei primi 32 termini, indicata con L₂, è un numero razionale strettamente minore di log 2. Per p > 1 e e = floor(log₂p), si ha log p > eL₂.

Per 694 righe su 696 basta verificare con interi esatti

\[
(eL_2)^2>g-1.
\]

Questo implica ceil(log²p) ≥ g. Per i soli primi 3 e 7 si aggiunge il limite inferiore razionale

\[
2\sum_{j=0}^{7}\frac{z^{2j+1}}{2j+1},\qquad
z=\frac{p-2^e}{p+2^e},
\]

che è minore o uguale a log(p/2^e). Il margine minimo certificato rispetto a g − 1 supera 0,2069. Tutti i confronti che stabiliscono il risultato sono razionali esatti; le rappresentazioni decimali nel riepilogo servono soltanto alla lettura.

## 3. Il primo di confine

La somma dei gap contati telescopa. Se P_* è l'ultimo primo incluso, allora

\[
P_*=2+\sum_g gN(g)
=3\,999\,999\,999\,999\,999\,887.
\]

Questo primo è 113 interi sotto 4 × 10¹⁸. La sua primalità è stata verificata anche separatamente con un certificato di Lucas basato sulla fattorizzazione completa di P_* − 1 e su certificati ricorsivi dei fattori. Il certificato contiene 20 nodi. Il verificatore usa soltanto potenze modulari, prodotti e massimi comuni divisori, senza test di probabile primalità.

Il filtro Miller–Rabin impiegato dal generatore serve a trovare le fattorizzazioni; la validità del certificato finale viene ricontrollata senza usarlo.

## 4. Un primo dopo ogni intero sotto P_*

Sia 2 ≤ m < P_*. Siano a il massimo primo ≤ m e b il primo successivo. Essendo P_* primo e maggiore di m, si ha b ≤ P_*. Il gap (a,b) rientra quindi nella scansione pubblicata e soddisfa

\[
b-a\leq\lceil(\log a)^2\rceil.
\]

Poiché a ≤ m e il logaritmo è crescente,

\[
0<b-m\leq b-a
\leq\lceil(\log a)^2\rceil
\leq\lceil(\log m)^2\rceil.
\]

Pertanto ogni intero m in questo intervallo, e in particolare ogni punto Sparacino M, ha un primo nella finestra richiesta.

Il limite inclusivo sul prodotto è P_* − 1 = 3.999.999.999.999.999.886. Non si usa alcun gap esterno alla scansione per trattare il confine.

## 5. Un limite uniforme sul primo iniziale p₁

Poniamo

\[
L=\left\lfloor\frac{P_*-1}{1132}\right\rfloor
=3\,533\,568\,904\,593\,639.
\]

Per ogni coppia consecutiva p₁ ≤ L, il postulato di Bertrand garantisce p₂ < 2p₁ ≤ 2L < 4 × 10¹⁸. Il gap d appartiene quindi alla scansione pubblicata.

Nella tabella, la prima occorrenza di un gap maggiore di 1132 inizia a

\[
43\,841\,547\,845\,541\,059,
\]

con gap 1184. Questo primo è maggiore di L. Ne segue d ≤ 1132 per tutte le coppie con p₁ ≤ L. Dunque

\[
M=dp_1\leq1132L
=3\,999\,999\,999\,999\,999\,348<P_*.
\]

Il risultato del paragrafo 4 conclude la verifica finita della congettura su tutto l'intervallo p₁ ≤ L.

## 6. Limiti più ampi quando il gap è fissato

La condizione sul prodotto dà direttamente questi intervalli, per le coppie che hanno il gap indicato:

| Gap d | Limite inclusivo su p₁ |
|---:|---:|
| 2 | 1.999.999.999.999.999.943 |
| 4 | 999.999.999.999.999.971 |
| 6 | 666.666.666.666.666.647 |
| 12 | 333.333.333.333.333.323 |
| 30 | 133.333.333.333.333.329 |
| 60 | 66.666.666.666.666.664 |

Questi limiti riguardano tutte le coppie valide entro ciascuna regione, non un campione. La loro dimostrazione dipende dalla tabella esaustiva pubblicata e dalla monotonia dei limiti sui gap.

## 7. Che cosa cambia per il problema aperto

È stato ottenuto un limite superiore della lunghezza richiesta su un intervallo finito molto ampio. Non è stato dimostrato un limite superiore valido oltre la copertura computazionale: il passaggio a tutti i p₁ resta aperto.

Questo risultato non convalida retroattivamente il vecchio registro GPU o il test a 15 basi fino a 10³⁰. Stabilisce una copertura finita distinta, con fonte, riduzione e certificati dichiarati.

## Riproducibilità

File nella cartella di lavoro:

- `fonti_esterne/oliveira_prime_gaps_t0.txt.gz`: originale scaricato dal sito dell'autore;
- `fonti_esterne/oliveira_prime_gaps_t0.txt`: copia decompressa;
- `certifica_estensione_finita.py`: controlli razionali, ricostruzione del confine, generazione e verifica del certificato di Lucas;
- `certificato_estensione_finita.json`: tutte le 696 righe controllate, risultati, limiti esatti, impronte e certificati di primalità.

Esecuzione con la sola libreria standard di Python:

```text
python certifica_estensione_finita.py
```

Le assunzioni esterne sono la correttezza e completezza della scansione pubblicata dei gap, oltre ai teoremi elementari usati nella deduzione. Non viene assunta la verità di Cramér, Firoozbakht o della congettura Sparacino oltre il campo verificato.
