# Hardy–Littlewood mediata e controesempi: un teorema condizionale e i suoi limiti

25 ottobre 2026. Seguito di `Dimostrazione_universale_Sparacino_2026-10-25.md`, §8.1.

**Esito.**

- **Dimostrato (Teorema 4).** Si adatta il Teorema 1.6 di Banks, Ford e Tao [1] ai sistemi di forme lineari {n, n + 2, 2n + h}. Un'ipotesi di Hardy–Littlewood mediata con errore O(x^{1−c}) implica, per ogni c′ < 2c·e^{−γ} e ogni x grande, l'esistenza di coppie gemelle p, p + 2 con p ∈ (x/2, x] e nessun primo in (2p, 2p + c′·log²x].
- **Conseguenza.** Se c > e^γ/2 = 0,8905…, si ottengono infiniti controesempi alla congettura con costante 1: almeno x^{1−c′e^γ/2−o(1)} con p ∈ (x/2, x], cioè quasi x^{0,11} per c′ vicino a 1.
- **Limite decisivo.** Un'ipotesi con c > 1/2 non è plausibile. Già per k = 0 chiede che il conteggio dei primi gemelli abbia errore inferiore a x^{0,11}. Per i primi stessi, il teorema di Littlewood esclude ogni errore O(x^{1−c}) con c > 1/2; la stessa ipotesi di Banks–Ford–Tao, applicata ai primi, è falsa per c > 1/2.
- **Con l'ipotesi più forte plausibile** (c < 1/2) il teorema dà finestre vuote di lunghezza (e^{−γ} − ε)·log²M ≈ 0,56·log²M dopo infiniti punti M = 2p. La scala log² risulta necessaria, ma la costante 1 non viene decisa.

Il teorema condizionale richiesto è quindi dimostrato. Non fornisce però una riduzione credibile del tipo «Hardy–Littlewood implica che la congettura sia falsa». L'ostacolo è strutturale (§5).

## 1. Il modello e l'ipotesi

### 1.1 Notazione

𝒫 è l'insieme dei primi e Θ_z = ∏_{p≤z}(1 − 1/p). Come in [1, (1.7)], per t ≥ e² sia z(t) il massimo primo con 1/Θ_{z(t)} ≤ log t. Allora z(t) = t^{e^{−γ}+o(1)} e Θ_{z(t)}^{−1} = log t + O(t^{−1/e^γ}).

Per ℋ ⊂ [1, y] e p primo poniamo

\[
\nu_{\mathcal H}(p)=\#\Big\{m\in\mathbb Z/p:\ p\ \Big|\ m(m+2)\prod_{h\in\mathcal H}(2m+h)\Big\},\qquad
\nu'_{\mathcal H}(p)=\#\Big\{m\in\mathbb Z/p:\ p\ \Big|\prod_{h\in\mathcal H}(2m+h)\Big\},
\]

e

\[
\mathfrak M_t(\mathcal H)=\prod_{p\leq z(t)}\Big(1-\frac{\nu_{\mathcal H}(p)}{p}\Big)\prod_{z(t)<p\leq z(2t)}\Big(1-\frac{\nu'_{\mathcal H}(p)}{p}\Big).
\]

### 1.2 Il modello dell'intero casuale

Per ogni primo p sia n_p un residuo uniforme in ℤ/p, con n_p indipendenti. Fissato t, consideriamo l'evento e la variabile

\[
\mathrm{tw}(t)=\{n_p\notin\{0,-2\}\ \text{per ogni}\ p\leq z(t)\},\qquad
S_t=\#\{h\in[1,y]:\ 2n_p+h\not\equiv0\ (\mathrm{mod}\ p)\ \text{per ogni}\ p\leq z(2t)\}.
\]

Per indipendenza fra i primi si ha 𝔐_t(ℋ) = P(tw(t) e ℋ ⊂ S_t). Sommando su ℋ,

\[
\sum_{\mathcal H\subset[1,y],\ |\mathcal H|=k}\mathfrak M_t(\mathcal H)=\mathbb E\Big[\mathbf 1_{\mathrm{tw}(t)}\binom{S_t}{k}\Big]. \tag{1}
\]

I primi fino a z(t) agiscono su n e n + 2, che hanno grandezza t; quelli fino a z(2t) agiscono sulle forme 2n + h, che hanno grandezza 2t. Per ℋ fissato, 𝔐_t(ℋ) = (1 + o(1))·𝔖(ℋ)/((log t)²(log 2t)^k), dove 𝔖(ℋ) è la serie singolare di Hardy–Littlewood del sistema. È quindi la previsione di Hardy–Littlewood con la serie singolare troncata, come suggerito da Pólya e adottato in [1].

### 1.3 L'ipotesi

**Ipotesi HL-S(c, c′).** Per ogni x sufficientemente grande, con y = ⌊c′ log²x⌋, uniformemente per gli interi 0 ≤ k ≤ 60c′ log x,

\[
\Sigma_k(x):=\sum_{\substack{\mathcal H\subset[1,y]\\|\mathcal H|=k}}\#\big\{n\in\mathbb Z\cap(\tfrac x2,x]:\ n,\ n+2\in\mathcal P,\ 2n+h\in\mathcal P\ \forall h\in\mathcal H\big\}
=\int_{x/2}^{x}\sum_{|\mathcal H|=k}\mathfrak M_t(\mathcal H)\,dt+O(x^{1-c}).
\]

È la trasposizione dell'ipotesi (1.18) di [1]: media su tutte le k-uple di una lunghezza fissata, errore uniforme e termine principale scritto con le densità del modello. Quest'ultima scelta non è un dettaglio. I singoli termini di Bonferroni sono enormemente più grandi del risultato finale, e alla precisione richiesta sostituire Θ_{z(t)} con 1/log t, o log(2t + h) con log 2t, introdurrebbe errori maggiori del termine principale cercato.

## 2. Il teorema

**Teorema 4 (condizionale).** Siano 0 < c < 1 e 0 < c′ < 2c·e^{−γ}, e valga HL-S(c, c′). Sia T(x) il numero di interi n ∈ (x/2, x] con n e n + 2 primi e nessun primo in (2n, 2n + ⌊c′ log²x⌋]. Allora

\[
T(x)\geq x^{\,1-c'e^{\gamma}/2-o(1)}\qquad(x\to\infty).
\]

**Corollario 4.1.** Se c > e^γ/2 e HL-S(c, c′) vale per qualche c′ ∈ (1, 2c e^{−γ}), la congettura Sparacino ha infiniti controesempi: per x grande ce ne sono almeno x^{1 − c′e^γ/2 − o(1)} con p ∈ (x/2, x].

*Dimostrazione.* Per n ≤ x si ha ⌈log²(2n)⌉ ≤ (log x + log 2)² + 1 < ⌊c′ log²x⌋ per x grande, perché c′ > 1. Due primi gemelli sono consecutivi, quindi ogni n contato da T(x) dà un controesempio con M = 2n. ∎

**Corollario 4.2.** Se HL-S(c, c′) vale per ogni c < 1 e ogni c′ < 2c e^{−γ}, allora lungo le coppie gemelle

\[
\limsup\frac{K}{\log^2M}\geq2e^{-\gamma}=1{,}1229\ldots,
\]

cioè il valore previsto dal modello di Granville.

## 3. Dimostrazione del Teorema 4

Poniamo L = log x e y = ⌊c′L²⌋. Fissiamo η > 0 abbastanza piccolo perché (1 + η)c′e^γ/2 < c. Sia K = 2⌈4e²y/L⌉ − 1, che è dispari; per x grande vale K ≤ 60c′L.

### Passo 1: crivello di Bonferroni pesato

Siano w_n = 1_𝒫(n)·1_𝒫(n + 2) ≥ 0 e A(n) il numero di primi in (2n, 2n + y]. Poniamo δ(m) = 1 se m = 0 e δ(m) = 0 altrimenti, e δ_K(m) = ∑_{k≤K}(−1)^k C(m, k). Per K dispari vale δ(m) ≥ δ_K(m) (Lemma 8.1 di [1]). Quindi

\[
T(x)=\sum_{x/2<n\leq x}w_n\,\delta(A(n))\ \geq\ \sum_{k=0}^{K}(-1)^k\sum_{x/2<n\leq x}w_n\binom{A(n)}{k}=\sum_{k=0}^{K}(-1)^k\,\Sigma_k(x)=:U_K.
\]

### Passo 2: dall'ipotesi al modello

Per l'ipotesi e per l'identità (1),

\[
U_K=\int_{x/2}^{x}\mathbb E\big[\mathbf 1_{\mathrm{tw}(t)}\,\delta_K(S_t)\big]\,dt+O\big((K+1)x^{1-c}\big).
\]

### Passo 3: troncamento

Per K dispari e m ≥ 1 si ha δ_K(m) = −C(m − 1, K) ≥ −C(m, K + 1). Quindi δ_K(m) ≥ δ(m) − C(m, K + 1) per ogni m ≥ 0, e

\[
U_K\geq\int_{x/2}^{x}\Big(\mathbb P\big(\mathrm{tw}(t),\ S_t=0\big)-\mathbb E\binom{S_t}{K+1}\Big)dt-O(Kx^{1-c}).
\]

### Passo 4: il resto di Bonferroni è trascurabile

La forma 2n + h viene tolta dal primo p quando h ≡ c_p (mod p), con c_p = −2n_p. Per p dispari le classi c_p sono uniformi e indipendenti; per p = 2 si toglie sempre la classe degli h pari. Condizioniamo sui residui con p ≤ y e indichiamo con S_y i sopravvissuti in [1, y]. Per p > y ogni (K + 1)-upla ha K + 1 residui distinti, e 1 − (K + 1)/p ≤ (1 − 1/p)^{K+1}. Quindi

\[
\mathbb E\binom{S_t}{K+1}\leq\binom{\lfloor4y/\log y\rfloor}{K+1}\Theta_{y,z(2t)}^{\,K+1}
\leq\Big(\frac{8e\,y}{(K+1)L}\Big)^{K+1}\leq e^{-(K+1)}\leq x^{-59c'}.
\]

Qui S_y ≤ 4y/log y vale deterministicamente per il grande crivello di Montgomery e Vaughan [3]. Infatti S_y evita una classe modulo ogni primo p ≤ √y, e quindi |S_y| ≤ (y + y)/log √y. Inoltre Θ_{y,z(2t)} ≤ 2 log y/L per x grande, e K + 1 ≥ 8e²y/L ≥ 8e²(1 − o(1))c′L.

### Passo 5: la probabilità di una finestra vuota nel modello

Mostriamo che, uniformemente per t ∈ (x/2, x],

\[
\mathbb P\big(\mathrm{tw}(t),\ S_t=0\big)\geq x^{-(1+\eta)c'e^{\gamma}/2-o(1)}. \tag{2}
\]

Siano z₁ il massimo primo ≤ L/log L e w = y⁸. Allora z₁ < w < z(t) ≤ z(2t) e u₁ = log y/log z₁ → 2.

**(a) Primi piccoli.** Sia Π l'evento n₂ = 1, n₃ = 2 e n_p = −1/2 (mod p) per 5 ≤ p ≤ z₁. Si ha P(Π) = 1/∏_{p≤z₁} p = e^{−θ(z₁)} = x^{−o(1)}. Il calcolo del Lemma 1 della nota principale, applicato ai residui n_p, mostra che sotto Π vale tw fino a z₁ e che i sopravvissuti della finestra dopo i primi ≤ z₁ formano l'insieme J del Lemma 2, con

\[
|J|=S_G(y,z_1)=\Big(\tfrac12+o(1)\Big)\frac{y}{\log z_1}.
\]

**(b) Primi medi, z₁ < p ≤ w.** Condizionata a n_p ∉ {0, −2}, che ha probabilità 1 − 2/p, la classe c_p = −2n_p è uniforme su ℤ/p ∖ {0, 4}. Sia S_w il numero di elementi di J sopravvissuti. Si ha

\[
\mathbb E[S_w]=\sum_{h\in J}\ \prod_{z_1<p\leq w}\Big(1-\frac{\mathbf 1[h\not\equiv0,4\ (p)]}{p-2}\Big)\leq(1+o(1))\,|J|\,\Theta_{z_1,w},
\]

perché h(h − 4) ≠ 0, |h(h − 4)| < y², e quindi h(h − 4) ha al più 5 fattori primi maggiori di z₁. Per la disuguaglianza di Markov, con probabilità almeno η/(1 + η) vale S_w ≤ s₀ := (1 + η)(1 + o(1))|J|Θ_{z₁,w}.

**(c) Primi grandi, w < p ≤ z(2t).** Sia R l'insieme dei sopravvissuti, con |R| ≤ s₀. Per p ∈ (w, z(t)] serve n_p ∉ {0, −2}, che ha probabilità 1 − 2/p; condizionata a questo, la classe c_p è uniforme su ℤ/p ∖ {0, 4}. Per p ∈ (z(t), z(2t)] le classi sono uniformi.

Accoppiamento: si estrae c′_p uniforme su ℤ/p e si pone c_p = c′_p se c′_p ∉ {0, 4}, altrimenti si riestrae c_p uniforme su ℤ/p ∖ {0, 4}. La classe c_p ha la legge giusta. Inoltre le classi 0 e 4 non contengono elementi di R, che sono dispari, compresi in [1, y] e minori di p. Ogni elemento di R tolto da c′_p è quindi tolto anche da c_p. La probabilità di togliere tutto R è perciò almeno quella con classi uniformi.

Per quest'ultima vale il Lemma 6.3 di [1], con 𝒫 l'insieme dei primi in (w, z(2t)], g = 0 e w = y⁸. La sua dimostrazione usa solo che R sia un insieme fissato di al più 10y interi, distinti modulo ogni p ∈ 𝒫. Si ottiene

\[
\mathbb P_{\mathrm{unif}}(R\ \text{tolto})=(1-\Theta_{w,z(2t)})^{|R|}\big(1+O(y^{-5})\big).
\]

**(d) Conclusione del passo.** Per indipendenza fra i primi,

\[
\mathbb P(\mathrm{tw}(t),S_t=0)\geq e^{-\theta(z_1)}\prod_{z_1<p\leq z(t)}\Big(1-\frac2p\Big)\cdot\frac{\eta}{1+\eta}\cdot\frac12\,(1-\Theta_{w,z(2t)})^{s_0}.
\]

I primi due fattori sono x^{−o(1)}. Poiché Θ_{w,z(2t)} → 0,

\[
s_0\,\Theta_{w,z(2t)}=(1+\eta)(1+o(1))\,|J|\,\Theta_{z_1,z(2t)}
\leq(1+\eta)(1+o(1))\cdot\frac12\frac{y}{\log z_1}\cdot\frac{e^{\gamma}\log z_1}{\log 2t}
\leq(1+\eta)\Big(\frac{e^{\gamma}}2+o(1)\Big)c'L,
\]

usando Θ_{z(2t)} ≤ (1 + o(1))/log 2t, 1/Θ_{z₁} = (e^γ + o(1)) log z₁ (Mertens) e log 2t ≥ L. Questo prova (2).

### Passo 6: conclusione

Dai passi 1–5,

\[
T(x)\geq\frac x2\,x^{-(1+\eta)c'e^{\gamma}/2-o(1)}-\frac x2\,x^{-59c'}-O(x^{1-c}\log x).
\]

Il primo termine domina, perché (1 + η)c′e^γ/2 < c e (1 + η)c′e^γ/2 < 59c′. Dunque T(x) ≥ x^{1−(1+η)c′e^γ/2−o(1)} per ogni η > 0 abbastanza piccolo, e quindi T(x) ≥ x^{1−c′e^γ/2−o(1)}. ∎

## 4. Quanto è plausibile l'ipotesi?

Il Teorema 4 dà controesempi solo se c > e^γ/2 ≈ 0,89. Ci sono tre ragioni per ritenere che un'ipotesi così forte non valga.

**(a) Il caso k = 0.** HL-S con k = 0 è il conteggio dei primi gemelli in (x/2, x] con errore O(x^{1−c}). Con c > 0,89 l'errore sarebbe inferiore a x^{0,11}. Per i primi stessi, Littlewood [4] ha dimostrato π(x) − li(x) = Ω±(x^{1/2} log log log x/log x): nessun errore O(x^{1−c}) con c > 1/2 è possibile. Per i primi gemelli non esiste un teorema analogo, ma ci si attende lo stesso ordine di fluttuazione.

**(b) L'ipotesi originale di Banks–Ford–Tao applicata ai primi.** Nella (1.18) di [1] con 𝒜 = 𝒫 e k = 1, il termine principale vale (y + 1)(li(x) − li(2)), perché 𝔖_z({h}) = 1. Il membro sinistro vale ∑_{0≤h≤y}(π(x + h) − π(h)) = (y + 1)π(x) + O(y²). L'ipotesi implicherebbe quindi

\[
\pi(x)-\mathrm{li}(x)=O\big(x^{1-c}/y+y\big),
\]

falso per c > 1/2 per il teorema di Littlewood. Per i primi il Teorema 1.6 di [1] può quindi applicarsi solo con c < 1/2, e dà al più un gap massimo di (e^{−γ} − o(1)) log²x, perché g(u) ≥ (1 + o(1))u. Questo è coerente con quanto scrivono gli autori stessi, che definiscono l'ipotesi «più speculativa» delle altre.

**(c) I momenti alti.** Per k dell'ordine di log x, il momento Σ_k è dominato dalle finestre con circa λ + k primi, dove λ ≈ (e^γ/2)c′ log x. Queste finestre sono rare: per k = λ hanno frequenza circa e^{−0,39λ}. In un modello casuale il loro numero fluttua come la propria radice quadrata. Per le finestre che interessano, con c′ > 1, la fluttuazione assoluta di Σ_k che ne risulta supera di molto x. L'ipotesi chiede quindi ai primi una regolarità che i modelli casuali stessi non possiedono. È una valutazione euristica, non un teorema.

**Che cosa resta con c < 1/2.** Il Teorema 4 dà c′ < 2c e^{−γ} < e^{−γ} = 0,5615…: infinite coppie gemelle senza primi in (2p, 2p + 0,56·log²(2p)]. Non contraddice la congettura, la cui finestra ha costante 1. Mostra però, condizionatamente, che nessuna finestra di lunghezza o(log²M) potrebbe funzionare: la scala della congettura è giusta, ed è la costante a essere in discussione.

| Errore nell'ipotesi | Finestre vuote garantite: c′ fino a | Contraddice la congettura? |
|---|---|---|
| x^{1−c}, c < 1/2 (massimo plausibile) | 2c e^{−γ} < 0,5615 | no |
| x^{1−c}, 1/2 ≤ c ≤ e^γ/2 | 2c e^{−γ} ≤ 1 | no |
| x^{1−c}, c > e^γ/2 ≈ 0,8905 | 2c e^{−γ} > 1 | sì |
| x^{1−c} per ogni c < 1 | 2e^{−γ} ≈ 1,1229 | sì, con limsup ≥ 2e^{−γ} |

## 5. L'ostacolo strutturale

Nel modello di Granville i controesempi con p ≤ x sono dell'ordine di x^{1−e^γ/2} = x^{0,11}: pochissimi rispetto alle x/log²x coppie gemelle. Un argomento che ne deduca l'esistenza dai conteggi di k-uple, mediati o no, deve controllare quei conteggi con un errore più piccolo del numero di controesempi, cioè inferiore a x^{0,11}. Ci si attende invece che i conteggi fluttuino almeno come x^{1/2}.

Per questo la via «Hardy–Littlewood implica controesempi» non può funzionare con ipotesi di forza realistica. Una dimostrazione condizionale credibile richiederebbe un'ipotesi sugli eventi rari stessi, cioè una forma di Hardy–Littlewood per le grandi deviazioni. Equivarrebbe sostanzialmente ad assumere il modello di Granville, che è già il contenuto del Teorema 3.

Il Teorema 4 resta utile in due sensi. Identifica con precisione l'ipotesi minima che servirebbe per questa via, e mostra con un'ipotesi più debole che la scala log²M della congettura è necessaria.

## 6. Controlli esatti

Lo script `verifica_teorema_condizionale.py` controlla con frazioni esatte, su casi piccoli, le identità usate:

| Controllo | Caso | Esito |
|---|---|---|
| identità (1) | tagli Z₁ = 11 e Z₂ = 13, y = 12, k = 0,…,5, media su n modulo 30.030 | uguaglianza esatta per ogni k |
| δ_K(m) ≥ δ(m) − C(m, K + 1) | K dispari ≤ 41, m ≤ 300 | nessuna violazione |
| accoppiamento del passo 5(c) | s ≤ 8 elementi, primi in (20, 400]; forza bruta su un caso con primi 7 e 11 | probabilità condizionata ≥ uniforme; formule confermate |
| media del passo 5(b) | y = 60, schema fino a 5, primi medi 7, 11, 13 (495 combinazioni) | formula esatta |

I risultati sono in `verifica_teorema_condizionale.json`.

```text
python verifica_teorema_condizionale.py
```

## Fonti

[1] W. Banks, K. Ford, T. Tao, *Large prime gaps and probabilistic models*, Invent. Math. 233 (2023), 1471–1518. [arXiv:1908.08613](https://arxiv.org/abs/1908.08613). Usati: (1.7), (1.18), il Teorema 1.6 e la sua dimostrazione (§8), il Lemma 6.3 e i limiti (1.14) per g(u). Copia locale: `fonti_esterne/banks_ford_tao_2023_arXiv_1908.08613v3.pdf`.

[2] Nota principale: `Dimostrazione_universale_Sparacino_2026-10-25.md`, Lemmi 1 e 2.

[3] H. L. Montgomery, R. C. Vaughan, *The large sieve*, Mathematika 20 (1973), 119–134.

[4] J. E. Littlewood, *Sur la distribution des nombres premiers*, C. R. Acad. Sci. Paris 158 (1914), 1869–1872.
