# Avanzamento dopo le nuove aggiunte: un teorema sui primi reali e correzioni ai modelli

25 ottobre 2026. Audit e seguito delle note `Dimostrazione_universale_Sparacino_2026-10-25.md` e `Teorema_condizionale_Sparacino_2026-10-25.md`.

**Stato della congettura: aperta.** Non è stata dimostrata né confutata per i primi reali. È stato invece completato il seguente rafforzamento incondizionato della costruzione precedente:

> Esistono costanti assolute a > 0 e D tali che, per ogni X sufficientemente grande, esiste una coppia di primi consecutivi p, p+d con X ≤ p ≤ 3X, d ≤ D, per cui, posto M = dp, tutti gli interi M+1,…,M+⌊a log log M⌋ sono composti. Inoltre uno stesso valore fissato d_* ricorre in infinite coppie con questa proprietà.

La costante a non è resa numericamente esplicita. Il risultato usa il teorema uniforme di Maynard e non assume congetture sui primi gemelli, Hardy–Littlewood, RH o un modello casuale. È una deduzione sviluppata qui; non si rivendica una priorità bibliografica.

Il risultato riguarda i casi sfavorevoli: K cresce almeno come log log M lungo una sottosuccessione. Rimane molto più piccolo di log² M, dunque è compatibile con la congettura originale.

## 1. Che cosa è stato letto e ricontrollato

Sono stati letti integralmente le due nuove note e i tre programmi `esperimento_classi_residue.py`, `soglia_modello_raffinato.py`, `verifica_teorema_condizionale.py`, oltre al riepilogo dei materiali intermedi e ai passaggi rilevanti di Banks–Ford–Tao e Maynard nelle fonti primarie.

Controlli ripetuti:

- corrispondenza SHA-256 fra i due programmi sperimentali e i rispettivi file di risultati;
- lunghezze N, conteggi delle posizioni libere S_z, previsioni λ_z, medie ed errori standard su **tutte le 2.760 finestre**;
- ricontrollo di **24 finestre**, due per gruppo e per scala, comprendendo i massimi K/N di ogni gruppo: filtro indipendentemente riscritto fino a 5.000 e test di Miller–Rabin con basi 2, 3 e 32 basi aggiuntive pseudocasuali; conteggi e primi offset coincidono;
- identità dei momenti, disuguaglianza di Bonferroni, accoppiamento e media condizionata nel programma del teorema condizionale: controlli finiti superati.

I test a 60/100 cifre rimangono test di **primalità probabile**, non certificati di primalità. Gli esperimenti sono coerenti con i risultati dichiarati, nei limiti del metodo utilizzato. I controlli finiti delle identità non costituiscono una verifica di un teorema asintotico.

File aggiunti: `verifica_avanzamento_rigoroso.py` e `certificato_avanzamento_rigoroso.json`. I file ricevuti sono conservati senza sovrascriverli.

## 2. Tre conclusioni delle nuove note da correggere

### 2.1 Cramér non dà convergenza uniforme alla scala log² x

Nel §4.1 della nuova nota principale si afferma che, nel modello di Cramér, il numero di elementi in (x,x+log²x], diviso log x, tende quasi certamente a 1. Questa affermazione, con x che percorre tutti gli interi, è falsa.

Banks–Ford–Tao, §2.5, richiedono **y/log²x → ∞** per la corrispondente legge uniforme. Il risultato di Maier contraddice quella previsione, per esempio con y = log³x. La condizione non vale per y = log²x.

Si può precisare interamente il comportamento alla scala critica. Sia C il modello con etichette indipendenti di probabilità 1/log m per m ≥ 3, e poniamo

\[
Z(x)=\#\big(C\cap(x,x+\lceil\log^2x\rceil]\big).
\]

**Proposizione.** Quasi certamente, lungo gli x interi,

\[
\liminf_{x\to\infty}\frac{Z(x)}{\log x}=0,
\qquad
\limsup_{x\to\infty}\frac{Z(x)}{\log x}=e.
\]

*Dimostrazione.* Per α fissato positivo, α ≠ 1, le stime binomiali e la formula di Stirling danno, uniformemente per x ∈ [X,2X],

\[
\mathbb P(Z(x)\leq\alpha\log x)=X^{-I(\alpha)+o(1)}\quad(0<\alpha<1),
\]

e la stessa espressione per P(Z(x) ≥ α log x) se α > 1, dove I(α)=1−α+α log α. Infatti le probabilità delle singole etichette sono uniformemente (1+o(1))/log X e il numero di prove è (1+o(1))log²X; confronti con binomiali a parametro minimo e massimo e Stirling forniscono l'esponente indicato.

In [X,2X] scegliamo ≫ X/log²X finestre disgiunte. Per 0 < α < 1, oppure 1 < α < e, vale I(α)<1: il numero atteso dei corrispondenti eventi indipendenti cresce come X^{1−I(α)+o(1)}. La probabilità che nessuno si verifichi è al più exp(−X^{1−I(α)+o(1)}), sommabile sui blocchi X=2^j. Per il primo lemma di Borel–Cantelli gli eventi esistono in tutti i blocchi abbastanza grandi, quasi certamente. Per α>e, invece, I(α)>1: l'unione su tutti gli x interi del blocco ha probabilità al più X^{1−I(α)+o(1)}, anch'essa sommabile sui blocchi diadici. Intersecando su successioni numerabili α↓0 e α→e si ottengono i due limiti. ∎

Questa proposizione riguarda tutti gli interi x, non l'insieme speciale dei punti Sparacino. Non contraddice il precedente risultato nel modello ausiliario di Cramér sull'insieme fissato S dei punti reali, per il quale ∑_{M∈S}1/M converge.

### 2.2 Il «10%» non è una probabilità dimostrata per la congettura

Il numero 5–20% del §5.3 dipende da una stima media di 1/d e da momenti esponenziali stimati con campioni piccoli e tagli diversi. Non è un intervallo di confidenza e non determina la probabilità che la congettura sui primi reali sia falsa.

C'è anche una distinzione logica necessaria: in un modello che ha quasi certamente infiniti controesempi, la probabilità di almeno un controesempio **oltre qualsiasi soglia finita** è 1. Una probabilità del 10% può riferirsi soltanto a un modello ausiliario diverso, oppure a un intervallo limitato prima del regime asintotico, che va specificato. Non può descrivere l'intera coda nello stesso modello del Teorema 3.

La soglia stimata di circa quindici milioni di cifre è un'estrapolazione di una famiglia particolare di classi e di modelli con taglio variabile. Non è una soglia provata per i primi, né esclude eccezioni precedenti, né individua il primo controesempio nel modello completo. I conteggi medi osservati non convalidano automaticamente le probabilità di finestre completamente vuote.

### 2.3 La crescita del parametro del modello va fissata

La sola scrittura A=(log X)^{1−o(1)} non implica A=o(log X). Per esempio A=log X soddisfa la prima relazione ma non la seconda. Il passaggio log Q=o(log X), usato per contare i candidati nella classe critica, richiede un'ulteriore scelta.

La si può fare esplicitamente. Il §4 sotto completa una versione rigorosa del risultato nel modello con A=log X/log log X, gestendo anche i due intervalli diadici coinvolti e l'indipendenza. Il risultato ottenuto riguarda quel modello e non trasferisce i controesempi ai primi reali.

## 3. Teorema incondizionato: tratti composti di lunghezza a log log M

Manteniamo K=min{k≥1:dp+k è primo}. Dimostriamo l'enunciato iniziale.

### 3.1 La tupla e i buchi interni

Applichiamo il Teorema 3.4 di Maynard con m=2, ε=1/100. Fissiamo una dimensione k sufficiente per quel teorema e una tupla ammissibile di interi pari

\[
\mathcal H=\{h_1,\ldots,h_k\},\quad 0=h_1<\cdots<h_k=D.
\]

Per esempio h_i=(i−1)R, con R prodotto dei primi ≤k: per q≤k tutti gli h_i sono 0 modulo q, e per q>k al più k residui sono vietati. La tupla è quindi ammissibile.

Scriveremo B=A+Qn e useremo i candidati B+h_i. Per ogni j pari in [0,D] fuori dalla tupla scegliamo un primo distinto r_j>D e imponiamo B≡−j (mod r_j). Gli interi B+j diventano composti quando B è abbastanza grande. Imponiamo anche B dispari: i buchi con j dispari sono allora pari.

Scegliamo una costante C maggiore di tutti gli r_j, di D e di 2k+2. Per tutti i primi q≤C fissiamo residui di B che lasciano coprimi B+h_i; quelli appena prescritti sono compatibili, poiché r_j>D e j∉H. Per gli altri q≤C esiste un residuo consentito per ammissibilità.

Di conseguenza **tutti** gli interi fra B e B+D fuori dalla tupla saranno composti. Se almeno due dei B+h_i sono primi, due primi adiacenti fra essi sono anche primi consecutivi nell'insieme di tutti i primi.

### 3.2 Il precrivello riduce il numero di congruenze nuove

Sia H un parametro intero che tende all'infinito, con H>C+D². Per ogni primo C<q≤H scegliamo, indipendentemente e uniformemente, il residuo di B fra i q−k residui che evitano i k numeri −h_i. Sono distinti perché q>D.

Consideriamo tutte le coppie h_i<h_j. Scriviamo d=h_j−h_i e consideriamo i bersagli

\[
T_{i,j,s}=d(B+h_i)+s,\qquad 1\leq s\leq H.
\]

Se gcd(s,d)>1 il bersaglio è già composto. Supponiamo quindi gcd(s,d)=1 e poniamo

\[
F_{i,j}(s)=\prod_{\ell=1}^k\big(s-d(h_\ell-h_i)\big).
\]

Nessun fattore è zero: altrimenti d dividerebbe s. Inoltre tutti i fattori hanno valore assoluto ≤H+D².

Per q>C, q non divide d. La congruenza T_{i,j,s}≡0 (mod q) individua un solo residuo di B. Questo residuo è vietato dagli estremi precisamente quando q divide F_{i,j}(s). Dunque la probabilità di sopravvivenza al precrivello è

\[
\prod_{C<q\leq H}\left(1-\frac1{q-k}\right)
\prod_{\substack{C<q\leq H\\q\mid F_{i,j}(s)}}\frac{q-k}{q-k-1}.
\tag{3.1}
\]

Il primo prodotto è ≪_k 1/log H per Mertens: il rapporto con ∏(1−1/q) converge a una costante positiva. Per q>C>2k+2 vale

\[
\frac{q-k}{q-k-1}\leq\left(\frac q{q-1}\right)^2.
\]

Il secondo prodotto in (3.1) è pertanto al più

\[
\prod_{\ell=1}^k
\left(\frac{|s-d(h_\ell-h_i)|}{\varphi(|s-d(h_\ell-h_i)|)}\right)^2.
\tag{3.2}
\]

Serve un limite medio, anziché un limite nel caso peggiore. Per ogni intero fisso r≥1 esiste C_r finita tale che

\[
\sum_{m\leq T}\left(\frac m{\varphi(m)}\right)^r\leq C_rT.
\tag{3.3}
\]

Infatti scriviamo (m/φ(m))^r=∑_{v|m}a_r(v), dove a_r è moltiplicativa, sostenuta sugli interi senza fattori quadratici e a_r(q)=(q/(q−1))^r−1≥0. Allora la somma è al più T∑_v a_r(v)/v. Quest'ultima serie converge, essendo il suo prodotto euleriano ∏_q(1+a_r(q)/q) e a_r(q)/q=O_r(q^{−2}).

Applichiamo Hölder con k fattori alla somma in s di (3.2). Ciascun intero positivo m≤H+D² compare al più due volte come |s−d(h_ℓ−h_i)|. Usando (3.3) con r=2k, la somma è quindi al più

\[
2C_{2k}(H+D^2)\leq4C_{2k}H.
\]

Sommando sulle k(k−1)/2 coppie, il numero atteso dei bersagli coprimi con d ancora non eliminati è

\[
\mathbb E U_H\ll_{\mathcal H}\frac H{\log H}.
\tag{3.4}
\]

I residui fissati per q≤C possono soltanto eliminarne altri. Per media, **esiste** una scelta dei residui del precrivello che lascia al più C₁H/log H bersagli non eliminati, con C₁ dipendente solo dalla tupla fissata.

### 3.3 Eliminazione dei bersagli rimasti e dimensione del modulo

Scegliamo la configurazione data da (3.4). Per ciascun bersaglio rimasto scegliamo un primo nuovo e distinto

\[
q>H+D^2
\]

e imponiamo

\[
B\equiv-h_i-sd^{-1}\pmod q.
\tag{3.5}
\]

Nessun candidato B+h_ℓ è eliminato da questa congruenza. Se lo fosse, q dividerebbe il numero non nullo s−d(h_ℓ−h_i), il cui valore assoluto è ≤H+D²<q: impossibile.

Per il teorema dei numeri primi esiste una costante C₂, dipendente solo da C₁ e dalla tupla, tale che l'intervallo (H+D²,C₂H] contiene abbastanza primi distinti per tutte le congruenze (3.5), quando H è grande.

Il modulo Q finale è il prodotto dei primi ≤H e di questi nuovi primi. Pertanto

\[
\log Q\leq\vartheta(H)+\frac{C_1H}{\log H}\log(C_2H)
\leq C_0H
\tag{3.6}
\]

per una costante fissata C₀. Il teorema cinese del resto fornisce 0≤A<Q con tutti i residui richiesti. Ogni bersaglio T_{i,j,s}, per ogni coppia e ogni s≤H, è ora composto per B abbastanza grande.

Questo è il miglioramento rispetto alla costruzione con un primo nuovo per ciascun bersaglio: grazie al precrivello, log Q=O(H), mentre l'assegnazione diretta dava O(H log H).

### 3.4 Applicazione uniforme di Maynard

Fissiamo ora una grandezza fisica X e scegliamo

\[
H=\left\lfloor\frac{\log\log X}{4C_0}\right\rfloor,
\qquad T=\lceil X/Q\rceil.
\]

Da (3.6), Q≤(log X)^{1/4}. Consideriamo le k forme

\[
L_i(n)=Qn+A+h_i.
\]

Sono ammissibili. Per q|Q tutte le forme sono coprime con q per costruzione. Per q∤Q, la trasformazione n↦Qn+A è una biiezione modulo q e si usa l'ammissibilità della tupla originale.

I coefficienti soddisfano Q≤log T e 0≤A+h_i≤Q+D≪T per X grande. Il Teorema 3.4 di Maynard, con parametro x=T e y=T, si applica **uniformemente** a queste forme anche se Q e A dipendono da X. La soglia x₀ dipende da m ed ε, non dalle forme entro i limiti dichiarati nel teorema.

Esistono quindi ≫T/(log T)^k interi n∈[T,2T] per cui almeno due delle forme sono prime. Per la costruzione dei buchi interni, scegliendo due primi adiacenti fra questi si ottiene una coppia di primi consecutivi p,p+d, con d≤D. Inoltre

\[
X\leq p\leq 2X+3Q+D\leq3X,
\qquad K>H.
\]

Poiché M=dp∈[2X,3DX], log log M=log log X+o(1). Riducendo la costante, per esempio scegliendo a=1/(8C₀), tutti gli interi M+s con s≤⌊a log log M⌋ sono composti per X grande.

Per H grande Q>D, quindi gli intervalli Qn+A+[0,D] relativi a n diversi sono disgiunti: danno coppie diverse. Il ragionamento produce anche il limite di quantità, con costanti non esplicitate,

\[
\#\{p\in[X,3X]:d\leq D,\ K>H\}
\gg\frac{X}{(\log X)^{k+1}}.
\]

Infine prendiamo X=4^j per avere intervalli disgiunti. I valori di d possibili sono finiti; almeno un d_* compare infinite volte. Questo completa la dimostrazione del teorema incondizionato. ∎

### 3.5 Verifica finita della parte algebrica

Con la tupla dimostrativa {0,2,6}, il nuovo programma ha verificato tutte le congruenze, la protezione degli estremi e la compositezza di ogni bersaglio:

| H | Bersagli iniziali coprimi con d | Primi nuovi dopo il precrivello | log Q / H |
|---:|---:|---:|---:|
| 64 | 85 | 20 | 2,3853 |
| 256 | 341 | 66 | 2,5014 |
| 1024 | 1365 | 229 | 2,6429 |

Le tabelle non dimostrano il limite asintotico (3.6), dimostrato sopra. La tupla di tre elementi serve a verificare l'algebra: **non** si sostiene che Maynard garantisca due primi in questa piccola tupla.

## 4. Completamento rigoroso del risultato nel modello di Granville

La conclusione probabilistica delle nuove aggiunte si può rendere precisa, con una scelta esplicita del modello. Per il blocco I_j=(2^j,2^{j+1}], poniamo, per j grande,

\[
A_j=\frac{\log(2^j)}{\log\log(2^j)},\quad
Q_j=\prod_{q\leq A_j}q,\quad
\Theta_j=\prod_{q\leq A_j}(1-1/q).
\]

Escludiamo gli interi non coprimi con Q_j e includiamo ciascun altro m∈I_j, indipendentemente per tutti gli m, con probabilità 1/(Θ_j log m). La definizione su un numero finito di blocchi iniziali è irrilevante e può essere scelta arbitrariamente. Per j grande la probabilità è minore di 1.

**Teorema nel modello.** Per ogni 0<c<2e^{−γ}, quasi certamente ci sono infiniti n tali che n,n+2 sono elementi consecutivi del modello e l'intervallo

\[
(2n,2n+\lceil c\log^2(2n)\rceil]
\]

è vuoto. Per c=1 si ottengono quindi infiniti controesempi alla versione della congettura **per questo insieme casuale**.

*Dimostrazione.* Scriviamo X=2^j, L=log X. Prendiamo n∈(X/2,X] con n,n+2∈I_{j−1} e con l'intera finestra dopo 2n contenuta in I_j; basta rimuovere O(L²) interi vicino ai bordi.

Imponiamo

\[
n\equiv5\pmod6,\qquad 2n\equiv-1\pmod q\quad(5\leq q\leq A_j).
\tag{4.1}
\]

La classe esiste per CRT ed evita la divisibilità di n,n+2 per tutti i primi ≤A_j, e quindi anche per quelli ≤A_{j−1}. Per PNT,

\[
\log Q_j=(1+o(1))A_j=o(L),
\]

così ci sono X^{1−o(1)} candidati n nella classe. Inoltre Q_j≫L²: finestre appartenenti a candidati distinti non si sovrappongono.

Sia y=⌈c log²(2n)⌉. Sotto (4.1), gli offset h superstiti dopo il crivello fino ad A_j sono precisamente quelli dispari, con h≢2 (mod 3) e gcd(h−1,∏_{5≤q≤A_j}q)=1. Il Lemma 2 della nuova nota principale, con log y/log A_j→2, dà

\[
S(y,A_j)=\left(\frac12+o(1)\right)\frac{y}{\log A_j}.
\]

Il fattore 1/2 è quello della funzione di Buchstab in u=2. La condizione di parità e quella modulo 3 si possono verificare ponendo h−1=2^a3^b r: a≥1; per b≥1 il peso totale è 1/2, per b=0 si prende metà degli r coprimi con 3 e il peso totale è ancora 1/2. Il risultato di Buchstab per gli r privi di fattori primi ≤A_j e Mertens danno la formula; le potenze di 2 e 3 grandi hanno una coda sommabile, come nella dimostrazione del lemma citato.

Per Mertens, ogni posizione libera è inclusa con probabilità (e^γ+o(1))log A_j/L. L'indipendenza delle etichette implica

\[
\mathbb P(\hbox{finestra vuota})
=\exp\left[-\left(\frac{ce^\gamma}{2}+o(1)\right)L\right]
=X^{-ce^\gamma/2+o(1)}.
\]

Il termine quadratico nell'espansione di log(1−ρ) contribuisce O(log A_j)=o(L), quindi non modifica l'esponente. L'inclusione di n e n+2 ha probabilità X^{−o(1)} e usa etichette del blocco I_{j−1}, disgiunte da quelle della finestra.

Anche per candidati diversi tutti gli insiemi di etichette coinvolti sono disgiunti: le coppie di ingresso stanno in I_{j−1}, le finestre in I_j, e la distanza Q_j fra candidati è molto maggiore di L². Gli eventi sono quindi indipendenti all'interno del blocco. Il loro numero atteso è

\[
\mu_j=X^{\delta+o(1)},\qquad\delta=1-\frac{ce^\gamma}{2}>0.
\]

La probabilità di non avere nessun evento è al più exp(−μ_j), sommabile in j. **Il primo** lemma di Borel–Cantelli basta: non occorre supporre indipendenti blocchi diadici successivi. Quasi certamente tutti i blocchi abbastanza grandi contengono almeno una coppia cercata. Una stima di Chernoff dà anche almeno μ_j/2 eventi, quasi certamente per tutti i j grandi.

L'intero n+1 è pari ed è escluso dal modello: n e n+2 sono consecutivi. Per c=1 l'assenza riguarda esattamente l'intera finestra della congettura. L'esponente di quantità è 1−e^γ/2=0,10946… . ∎

Si tratta di un teorema probabilistico rigoroso per il modello esplicitato. Non è una confutazione della congettura sui primi.

## 5. Il teorema condizionale e il punto ancora aperto

La nuova ipotesi HL-S(c,c′) contiene un controllo uniforme su momenti di ordine crescente e con **errore assoluto** O(x^{1−c}). È molto più forte della consueta formulazione di Hardy–Littlewood per ogni tupla fissata. Non si può sostituirla con quest'ultima nel ragionamento.

Le identità finite del nuovo programma sono corrette e l'impostazione con Bonferroni spiega il rapporto fra errore ammesso e lunghezza della finestra. La conclusione proposta richiede c′<2ce^{−γ}. Per superare la costante 1 occorre dunque c>e^γ/2≈0,8905. Con c<1/2 si arriva a c′<e^{−γ}≈0,56146 e **non** a un controesempio Sparacino. Il risultato di Littlewood sui primi singoli non è, da solo, una dimostrazione che HL-S sia falsa per c>1/2, poiché HL-S riguarda un diverso sistema di forme: la nota condizionale stessa distingue questo punto.

Né una soglia pratica né l'impossibilità assoluta di una futura dimostrazione seguono dai risultati attuali. La formulazione corretta è: gli argomenti sviluppati finora non dimostrano il limite superiore richiesto e non producono un controesempio reale.

Restano quindi distinti tre risultati:

1. **Limite superiore finito sui primi reali:** la proprietà originale è certificata per M<P_*=3.999.999.999.999.999.887, e in particolare per ogni coppia con p≤3.533.568.904.593.639, usando i dati esaustivi pubblicati e la riduzione esatta già salvata.
2. **Limite inferiore incondizionato sui primi reali:** il §3 dimostra K≥a log log M in infiniti casi con uno stesso gap d_* limitato.
3. **Superamento di log² M nel modello:** il §4 lo dimostra soltanto per l'insieme casuale definito lì.

Per chiudere la congettura originale occorre ancora un limite superiore uniforme alla scala log² M, oppure un punto M=dp con estremi consecutivi certificati e tutti gli interi della relativa finestra certificati composti. Nessuno dei nuovi esperimenti fornisce tale punto.

## Fonti primarie

- J. Maynard, *Dense clusters of primes in subsets*, Teorema 3.4: [testo arXiv v2](https://arxiv.org/html/1405.2593v2). Usati la dimensione fissata sufficiente per m=2 e l'uniformità per coefficienti limitati da potenze di log x.
- W. Banks, K. Ford, T. Tao, *Large prime gaps and probabilistic models*, versione corretta v3: [testo arXiv](https://arxiv.org/html/1908.08613v3). Usati §§1.2 e 2.5 per il modello e la corretta condizione y/log²x→∞; confrontati Teorema 1.6, Lemma 6.3 e §8 con la nuova nota condizionale.
- T. Oliveira e Silva, S. Herzog, S. Pardi, dati esaustivi dei gap: [pagina dell'autore](https://sweet.ua.pt/tos/gaps.html). La certificazione finita già presente è descritta in `Estensione_finita_Sparacino_2026-10-25.md`.

Mertens, PNT e Hölder sono usati nei limiti asintotici indicati. La stima dei momenti di m/φ(m) necessaria alla nuova costruzione è dimostrata esplicitamente in (3.3).
