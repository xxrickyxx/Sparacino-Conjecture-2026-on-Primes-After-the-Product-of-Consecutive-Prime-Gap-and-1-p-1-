#!/usr/bin/env python3
"""Primi nelle finestre di Sparacino per classi residue prescritte (gap d = 2).

Per una coppia gemella p, p + 2 (consecutiva automaticamente), M = 2p e
N = ceil(log(M)^2). Si conta il numero di primi in (M, M + N] e il primo
offset K, confrontando gruppi di M che differiscono soltanto per i residui
modulo i primi 5 <= q <= z:

  G  M = -1 (mod q) per ogni q: classe di tipo Granville, spostata di 1;
  W  classe avida "povera": per ogni q si toglie la classe di posizioni
     ancora libere più numerosa, fra quelle compatibili con p, p + 2 primi;
  R  classe avida "ricca": si toglie la classe meno numerosa;
  B  coppie gemelle generiche, senza vincoli di classe;
  C  interi M = 2m nella classe W, senza alcuna condizione di primalità;
  D  interi M = 2m generici, con m = 5 (mod 6).

Previsioni confrontate con le osservazioni:
  lambda_C = N / log M                                  (modello di Cramér)
  lambda_z = S_z(M) * prod_{q <= z} (1 - 1/q)^(-1) / log M  (setaccio fino a z)
dove S_z(M) è il numero di posizioni 1 <= n <= N con M + n coprimo con tutti
i primi <= z. lambda_1000 usa lo stesso modello con taglio 1009.

I test di primalità sono probabilistici: Miller-Rabin forte con 12 basi
fisse per gli estremi p, p + 2 e con 3 basi per i candidati nelle finestre,
dopo un crivello fino a 50.000. Bastano per una statistica; non sono
certificati. Il campionamento usa un seme fisso ed è riproducibile; le
finestre sono misurate in parallelo, senza effetto sui risultati.

Uso: python esperimento_classi_residue.py [--campioni 300 200] [--scale 60 100]
"""

import argparse
import hashlib
import json
import math
import os
import platform
import random
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from decimal import ROUND_CEILING, Decimal, getcontext
from functools import lru_cache
from pathlib import Path

getcontext().prec = 80

SEED = 20261025
MR_BASES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37)
WINDOW_BASES = (2, 3, 5)
SIEVE_LIMIT = 50_000
PRESIEVE_LIMIT = 2_000
MODEL_CUTOFF_2 = 1009


@lru_cache(maxsize=None)
def primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, math.isqrt(n) + 1):
        if sieve[i]:
            sieve[i * i :: i] = bytearray(len(range(i * i, n + 1, i)))
    return tuple(i for i in range(n + 1) if sieve[i])


SMALL_PRIMES = primes_upto(SIEVE_LIMIT)


def strong_probable_prime(n, a):
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x == 1 or x == n - 1:
        return True
    for _ in range(s - 1):
        x = x * x % n
        if x == n - 1:
            return True
    return False


def probable_prime(n, trial=True, bases=MR_BASES):
    if n < 2:
        return False
    if trial:
        for q in SMALL_PRIMES[:60]:
            if n % q == 0:
                return n == q
    return all(strong_probable_prime(n, a) for a in bases)


def window_length(M):
    L = Decimal(M).ln()
    return int((L * L).to_integral_value(rounding=ROUND_CEILING))


def log_of(M):
    return float(Decimal(M).ln())


def mark_window(M, N, primes):
    """bytearray m with m[n] = 1 iff some q in primes divides M + n (1 <= n <= N)."""
    marks = bytearray(N + 1)
    for q in primes:
        r = (-M) % q
        start = r if r else q
        if start <= N:
            marks[start::q] = b"\x01" * ((N - start) // q + 1)
    return marks


def primes_in_window(M, N):
    marks = mark_window(M, N, SMALL_PRIMES)
    count, first = 0, None
    n = marks.find(0, 1)
    while n != -1:
        if probable_prime(M + n, trial=False, bases=WINDOW_BASES):
            count += 1
            if first is None:
                first = n
        n = marks.find(0, n + 1)
    return count, first


@lru_cache(maxsize=None)
def mertens_inverse(z):
    prod = 1.0
    for q in primes_upto(z):
        prod *= 1.0 - 1.0 / q
    return 1.0 / prod


def build_class(kind, N_ref, z):
    """Residue c_q for each prime 5 <= q <= z: the window positions n = c_q (mod q) are removed,
    i.e. M = -c_q (mod q). c_q is never 0 or 4 (mod q), as required by p, p + 2 primes."""
    alive = [False] * (N_ref + 1)
    for n in range(1, N_ref + 1):
        alive[n] = n % 2 == 1 and n % 3 != 2  # M = 4 (mod 6)
    residues = {}
    for q in (q for q in primes_upto(z) if q >= 5):
        allowed = [c for c in range(1, q) if c != 4]
        if kind == "G":
            c = 1
        else:
            counts = [0] * q
            for n in range(1, N_ref + 1):
                if alive[n]:
                    counts[n % q] += 1
            if kind == "W":
                c = max(allowed, key=lambda c: (counts[c], -c))
            else:
                c = min(allowed, key=lambda c: (counts[c], c))
        residues[q] = c
        for n in range(c if c else q, N_ref + 1, q):
            alive[n] = False
    return residues


def class_progression(residues):
    """Progression a (mod Q) for p: p = 5 (mod 6) and 2p = -c_q (mod q) for every q."""
    a, Q = 5, 6
    for q, c in sorted(residues.items()):
        target = (-c * pow(2, -1, q)) % q
        t = ((target - a) * pow(Q, -1, q)) % q
        a, Q = a + Q * t, Q * q
    return a % Q, Q


def sample_progression(a, Q, lo, hi, count, rng, presieve, twins):
    """Uniform sample (without repetition) of x = a (mod Q) in [lo, hi); if twins, keep x, x + 2 prime."""
    kmin = -(-(lo - a) // Q)
    kmax = (hi - 1 - a) // Q
    if kmax - kmin < 10 * count:
        raise ValueError("progressione troppo corta per il campione richiesto")
    used, out = set(), []
    while len(out) < count:
        k = rng.randint(kmin, kmax)
        if k in used:
            continue
        used.add(k)
        x = a + k * Q
        if twins:
            if math.gcd(x * (x + 2), presieve) != 1:
                continue
            if not (probable_prime(x, trial=False) and probable_prime(x + 2, trial=False)):
                continue
        out.append(x)
    return out, len(used)


def measure(task):
    M, z = task
    N = window_length(M)
    logM = log_of(M)
    count, first = primes_in_window(M, N)
    S_z = N - mark_window(M, N, primes_upto(z)).count(1)
    S_z2 = N - mark_window(M, N, primes_upto(MODEL_CUTOFF_2)).count(1)
    minv_z, minv_z2 = mertens_inverse(z), mertens_inverse(MODEL_CUTOFF_2)
    return {
        "M": str(M),
        "N": N,
        "primi": count,
        "K": first,
        "S_z": S_z,
        "lambda_z": S_z * minv_z / logM,
        "lambda_1000": S_z2 * minv_z2 / logM,
        "lambda_C": N / logM,
    }


def summarize(rows):
    counts = [r["primi"] for r in rows]
    n = len(counts)
    mean = statistics.fmean(counts)
    sd = statistics.stdev(counts)
    se = sd / math.sqrt(n)
    lam_z = statistics.fmean(r["lambda_z"] for r in rows)
    lam_2 = statistics.fmean(r["lambda_1000"] for r in rows)
    lam_C = statistics.fmean(r["lambda_C"] for r in rows)
    Ks = [r["K"] for r in rows if r["K"] is not None]
    out = {
        "finestre_senza_primi": sum(r["K"] is None for r in rows),
        "n": n,
        "media_primi": mean,
        "dev_std_primi": sd,
        "errore_std": se,
        "media_lambda_z": lam_z,
        "media_lambda_1000": lam_2,
        "media_lambda_C": lam_C,
        "rapporto_osservato_su_Cramer": mean / lam_C,
        "errore_std_rapporto": se / lam_C,
        "rapporto_modello_z_su_Cramer": lam_z / lam_C,
        "z_osservato_meno_modello_z": (mean - lam_z) / se,
        "z_osservato_meno_modello_1000": (mean - lam_2) / se,
        "z_osservato_meno_Cramer": (mean - lam_C) / se,
        "minimo_primi": min(counts),
        "massimo_primi": max(counts),
        "media_K": statistics.fmean(Ks),
        "mediana_K": statistics.median(Ks),
        "massimo_K": max(Ks),
        "massimo_K_su_N": max(r["K"] / r["N"] for r in rows if r["K"] is not None),
    }
    lam = [r["lambda_1000"] for r in rows]
    if statistics.pstdev(lam) > 0:
        out["correlazione_primi_lambda_1000"] = statistics.correlation(counts, lam)
    return out


def run_scale(exp10, z, samples, log, pool):
    lo_M, hi_M = 10**exp10, 2 * 10**exp10
    lo_p, hi_p = lo_M // 2, hi_M // 2
    N_ref = window_length(3 * 10**exp10 // 2)
    primes_z = primes_upto(z)
    minv_z = mertens_inverse(z)
    rng = random.Random(SEED + exp10)

    def measure_all(Ms, key, values):
        rows = list(pool.map(measure, [(M, z) for M in Ms], chunksize=4))
        for row, v in zip(rows, values):
            row[key] = str(v)
        return rows
    presieve_class = math.prod(q for q in primes_upto(PRESIEVE_LIMIT) if q > z)
    presieve_all = math.prod(q for q in primes_upto(PRESIEVE_LIMIT) if q >= 5)

    classes = {}
    for kind in ("G", "W", "R"):
        res = build_class(kind, N_ref, z)
        a, Q = class_progression(res)
        S_ref = N_ref - mark_window(2 * a, N_ref, primes_z).count(1)
        classes[kind] = {"residui_c_q": res, "a": a, "Q": Q, "S_z_rif": S_ref,
                         "rapporto_previsto": S_ref * minv_z / N_ref}
        log(f"  classe {kind}: S_z = {S_ref}, rapporto previsto {S_ref * minv_z / N_ref:.4f}")

    groups, tried = {}, {}
    for kind in ("G", "W", "R"):
        a, Q = classes[kind]["a"], classes[kind]["Q"]
        ps, t = sample_progression(a, Q, lo_p, hi_p, samples, rng, presieve_class, twins=True)
        tried[kind] = t
        groups[kind] = measure_all([2 * p for p in ps], "p", ps)
        log(f"  gruppo {kind}: {samples} coppie gemelle ({t} candidati estratti)")
    ps, t = sample_progression(5, 6, lo_p, hi_p, samples, rng, presieve_all, twins=True)
    tried["B"] = t
    groups["B"] = measure_all([2 * p for p in ps], "p", ps)
    log(f"  gruppo B: {samples} coppie gemelle generiche ({t} candidati estratti)")
    a, Q = classes["W"]["a"], classes["W"]["Q"]
    ms, _ = sample_progression(a, Q, lo_p, hi_p, samples, rng, None, twins=False)
    groups["C"] = measure_all([2 * m for m in ms], "m", ms)
    log("  gruppo C: interi nella classe W")
    ms, _ = sample_progression(5, 6, lo_p, hi_p, samples, rng, None, twins=False)
    groups["D"] = measure_all([2 * m for m in ms], "m", ms)
    log("  gruppo D: interi generici")

    summary = {k: summarize(v) for k, v in groups.items()}
    comparisons = {}
    for k in ("G", "W", "R", "C", "D"):
        diff = summary[k]["media_primi"] - summary["B"]["media_primi"]
        se = math.hypot(summary[k]["errore_std"], summary["B"]["errore_std"])
        comparisons[f"{k}_meno_B"] = {
            "differenza_osservata": diff,
            "errore_std": se,
            "z": diff / se,
            "differenza_prevista_modello_z": summary[k]["media_lambda_z"] - summary["B"]["media_lambda_z"],
        }
    for k in classes:
        classes[k]["residui_c_q"] = {str(q): c for q, c in classes[k]["residui_c_q"].items()}
        classes[k]["a"], classes[k]["Q"] = str(classes[k]["a"]), str(classes[k]["Q"])
    return {
        "esponente": exp10,
        "intervallo_M": [str(lo_M), str(hi_M)],
        "z": z,
        "u": math.log(N_ref) / math.log(z),
        "N_rif": N_ref,
        "classi": classes,
        "candidati_estratti": tried,
        "riepilogo": summary,
        "confronti_con_B": comparisons,
        "campioni": groups,
    }


def largest_prime_at_most(x):
    x = int(x)
    while not (x > 1 and all(x % d for d in range(2, math.isqrt(x) + 1))):
        x -= 1
    return x


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--campioni", type=int, nargs="+", default=[300, 200],
                    help="campioni per gruppo, uno per scala (l'ultimo valore vale per le scale restanti)")
    ap.add_argument("--scale", type=int, nargs="+", default=[60, 100])
    ap.add_argument("--processi", type=int, default=os.cpu_count() or 1)
    ap.add_argument("--output", default="risultati_classi_residue.json")
    args = ap.parse_args()
    t0 = time.time()

    def log(msg):
        print(f"[{time.time() - t0:7.1f}s] {msg}", flush=True)

    results = []
    with ProcessPoolExecutor(max_workers=args.processi) as pool:
        for i, e in enumerate(args.scale):
            # z = largest prime <= sqrt(N): then n - 1 has at most one prime factor > z
            z = largest_prime_at_most(math.isqrt(window_length(10**e)))
            samples = args.campioni[min(i, len(args.campioni) - 1)]
            log(f"scala 10^{e}: z = {z}, {samples} campioni per gruppo")
            results.append(run_scale(e, z, samples, log, pool))
    script = Path(__file__).read_bytes()
    out = {
        "descrizione": "Primi nelle finestre (2p, 2p + ceil(log^2(2p))] per classi residue prescritte",
        "seme": SEED,
        "basi_miller_rabin_estremi": MR_BASES,
        "basi_miller_rabin_finestre": WINDOW_BASES,
        "limite_crivello_finestra": SIEVE_LIMIT,
        "python": sys.version,
        "piattaforma": platform.platform(),
        "sha256_script": hashlib.sha256(script).hexdigest(),
        "secondi": round(time.time() - t0, 1),
        "scale": results,
    }
    Path(args.output).write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    log(f"scritto {args.output}")


if __name__ == "__main__":
    main()
