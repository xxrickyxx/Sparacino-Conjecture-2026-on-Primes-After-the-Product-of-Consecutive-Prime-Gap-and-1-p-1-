"""Verifica esatta della congettura con crivelli indipendenti (nessun test probabilistico).

Esempio: python verifica_indipendente.py --limit 10000000 --count-to 2900000000
Dipendenza: numpy. Non esegue i programmi scaricati dal repository originale.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from decimal import Decimal, localcontext
from pathlib import Path

import numpy as np


def sieve(n: int) -> np.ndarray:
    flags = np.ones(n + 1, dtype=np.bool_)
    flags[:2] = False
    for p in range(2, math.isqrt(n) + 1):
        if flags[p]:
            flags[p * p :: p] = False
    return np.flatnonzero(flags)


def next_primes_for_queries(queries: np.ndarray, count_to: int, block: int):
    """Crivella tutti gli interi necessari; risolve anche query a cavallo dei blocchi."""
    order = np.argsort(queries, kind="stable")
    sorted_queries = queries[order]
    answers = np.zeros(len(queries), dtype=np.int64)
    stop = max(int(sorted_queries[-1]) + 10000, count_to)
    bases = sieve(math.isqrt(stop))
    cursor = 0
    count = 1  # il primo 2; i segmenti seguenti contengono solo dispari >= 3
    last_seen_prime = 2
    checkpoint_count = None
    checkpoint_last_prime = None
    t0 = time.perf_counter()
    for low in range(0, stop + 1, block):
        high = min(low + block - 1, stop)
        odd_low = low + 1  # block e low sono pari
        size = (high - odd_low) // 2 + 1
        flags = np.ones(size, dtype=np.bool_)
        if low == 0:
            flags[0] = False  # 1
        for pp in bases[1:]:
            p = int(pp)
            if p * p > high:
                break
            first = max(p * p, ((odd_low + p - 1) // p) * p)
            if first % 2 == 0:
                first += p
            flags[(first - odd_low) // 2 :: p] = False
        primes = odd_low + 2 * np.flatnonzero(flags)
        count_before = count
        count += len(primes)
        if low <= count_to <= high and count_to >= 2:
            included = int(np.searchsorted(primes, count_to, side="right"))
            checkpoint_count = count_before + included
            checkpoint_last_prime = int(primes[included - 1]) if included else last_seen_prime
        if len(primes) and cursor < len(queries):
            end = int(np.searchsorted(sorted_queries, primes[-1], side="left"))
            positions = np.searchsorted(primes, sorted_queries[cursor:end], side="right")
            answers[order[cursor:end]] = primes[positions]
            cursor = end
        if len(primes):
            last_seen_prime = int(primes[-1])
        if low % 500_000_000 == 0:
            print(f"Crivello fino a {high:,}; query risolte {cursor:,}/{len(queries):,}; {time.perf_counter()-t0:.1f} s", flush=True)
    if cursor != len(queries) or np.any(answers <= queries):
        raise RuntimeError("Una query non ha un primo successivo certificato dal crivello.")
    return answers, checkpoint_count, checkpoint_last_prime, stop


def row(i, p, p2, d, m, n, k):
    return {"p1": int(p[i]), "p2": int(p2[i]), "d": int(d[i]), "M": int(m[i]),
            "N": int(n[i]), "k": int(k[i]), "r": int(m[i] + k[i]), "k_over_N": float(k[i] / n[i])}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=10_000_000)
    parser.add_argument("--count-to", type=int, default=2_900_000_000)
    parser.add_argument("--block", type=int, default=10_000_000)
    args = parser.parse_args()
    if args.limit < 29 or args.block < 100 or args.block % 2:
        raise ValueError("Occorrono limit >= 29 e block pari >= 100.")
    t0 = time.perf_counter()
    primes = sieve(args.limit + 10000)
    count = int(np.searchsorted(primes, args.limit, side="right"))
    if count == len(primes):
        raise RuntimeError("Il margine non include il primo successivo al limite.")
    p, p2 = primes[:count], primes[1:count + 1]
    d = p2 - p
    m = d * p
    logs = np.log(m.astype(float))
    n = np.ceil(logs * logs).astype(np.int64)
    rng = np.random.default_rng(20261025)
    even_control = m + 2 * rng.integers(1, 10001, size=count)
    mod30_control = m + 30 * rng.integers(1, 668, size=count)
    queries = np.concatenate([m, even_control, mod30_control])
    print(f"Coppie {count:,}; massimo M {m.max():,}; seed 20261025", flush=True)
    answers, prime_count, checkpoint_last, sieve_stop = next_primes_for_queries(queries, args.count_to, args.block)
    k = answers[:count] - m
    ke = answers[count:2 * count] - even_control
    k30 = answers[2 * count:] - mod30_control

    # Certificato conservativo per la disuguaglianza: log(M) >= floor(log2 M)*a/b,
    # con a/b = 0.6931471805599453 < log(2). Il ceil si calcola con interi esatti.
    powers = np.searchsorted(np.array([1 << j for j in range(63)], dtype=np.int64), m, side="right") - 1
    a, b = 6931471805599453, 10**16
    lower_ceil = np.array([((j * a)**2 + b*b - 1) // (b*b) for j in range(63)], dtype=np.int64)[powers]
    borderline = np.flatnonzero(k > lower_ceil)
    decimal_failures = []
    with localcontext() as ctx:
        ctx.prec = 80
        for i in borderline:
            z = Decimal(int(m[i])).ln() ** 2
            # Lo scarto 10^-65 supera ampiamente l'errore di arrotondamento a 80 cifre.
            conservative_n = int((z - Decimal("1e-65")).to_integral_value(rounding="ROUND_CEILING"))
            if int(k[i]) > conservative_n:
                decimal_failures.append(int(i))

    mask = p >= min(1_000_000, args.limit // 10)
    ratios = k / n
    top = np.argsort(ratios)[-20:][::-1]
    worst = row(int(top[0]), p, p2, d, m, n, k)
    hist = np.bincount(k)
    by_d = []
    for dd in np.unique(d[mask]):
        chosen = mask & (d == dd)
        by_d.append({"d": int(dd), "count": int(chosen.sum()), "mean_k": float(k[chosen].mean()),
                     "mean_even_control": float(ke[chosen].mean()), "mean_mod30_control": float(k30[chosen].mean()),
                     "fraction_k1": float((k[chosen] == 1).mean()),
                     "mean_normalized_k": float((k[chosen] / logs[chosen]).mean())})
    # Lemma quadratico: test supplementare della formula dimostrata nella nota.
    square_checks = 0
    for t in (1, 3, 5, 7, 9):
        chosen = (p > t) & (np.gcd(d, t) == 1) & (d > 1)
        if np.any(np.gcd(m[chosen] + t*t, d[chosen] * np.abs(d[chosen]**2 - t*t)) != 1):
            raise AssertionError("Il lemma quadratico non passa il controllo.")
        square_checks += int(chosen.sum())
    result = {
        "date": "2026-10-25", "method": "Eratosthenes sieve, exact integer divisibility, no Miller-Rabin",
        "limit_p1_inclusive": args.limit, "pairs": count, "last_p1": int(p[-1]), "last_p2": int(p2[-1]),
        "max_M": int(m.max()), "max_d": int(d.max()), "sieve_stop": sieve_stop,
        "failures": len(decimal_failures), "worst_ratio": worst, "max_k": int(k.max()),
        "global_mean_k": float(k.mean()), "global_mean_k_over_log_M": float((k/logs).mean()),
        "integer_lower_bound_passes": count-len(borderline), "decimal_checked_remaining": len(borderline),
        "control_seed": 20261025, "control_min_p1": int(p[mask][0]), "control_pairs": int(mask.sum()),
        "mean_k_control_subset": float(k[mask].mean()), "mean_even_control": float(ke[mask].mean()),
        "mean_mod30_control": float(k30[mask].mean()), "fraction_k1": float((k[mask] == 1).mean()),
        "square_lemma_checks": square_checks, "count_checkpoint": args.count_to,
        "pi_checkpoint": prime_count, "last_prime_checkpoint": checkpoint_last,
        "pi_checkpoint_minus_one": None if prime_count is None else prime_count-1,
        "elapsed_seconds": time.perf_counter()-t0,
        "top_k": [{"k": int(i), "count": int(hist[i])} for i in np.argsort(hist)[-20:][::-1]],
        "by_gap": by_d,
        "worst_20": [row(int(i), p, p2, d, m, n, k) for i in top],
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    Path("risultati_verifica_indipendente.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    with Path("statistiche_indipendenti_per_gap.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=by_d[0].keys())
        writer.writeheader()
        writer.writerows(by_d)
    np.savez_compressed("verifica_indipendente_coppie.npz", p1=p, p2=p2, d=d, M=m, N=n, k=k,
                        even_control=even_control, even_control_k=ke, mod30_control=mod30_control,
                        mod30_control_k=k30)
    print(json.dumps({key: value for key, value in result.items() if key not in ("by_gap", "worst_20")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
