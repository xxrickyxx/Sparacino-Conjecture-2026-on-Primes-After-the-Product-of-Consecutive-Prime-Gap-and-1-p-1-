#!/usr/bin/env python3
"""Rapporti di sopravvivenza delle classi critiche e soglia del modello raffinato.

Per coppie gemelle p, p + 2 con 2p = -c_q (mod q) per i primi 5 <= q <= z, le
posizioni n della finestra (2p, 2p + y] con 2p + n coprimo con tutti i primi
<= z sono un insieme che dipende soltanto dalla classe. Si confronta il loro
numero S con il valore medio y * prod_{q <= z} (1 - 1/q):

    r = S / (y * prod_{q <= z} (1 - 1/q)).

Classe G: c_q = 1 per ogni q (2p = -1). Per G vale il limite rigoroso
r -> e^gamma * omega(u), u = log y / log z, con omega la funzione di Buchstab.
Classe W: scelta avida, che toglie a ogni passo la classe più numerosa.

Parte 1: r esatto, con crivello completo, per y = L^2 fino a 10^8.
Parte 2: r della classe G per L fino a 10^30, con pi(t) esatto fino a 10^7 e
         approssimato da li(t) - li(sqrt t)/2 oltre; convalida sulla parte 1.
Parte 3: logaritmo del numero atteso di controesempi in [X, 2X], X = e^L,
         nel modello di Granville con taglio z:
           F = log C2 + L - 2 log L - sum_{5<=q<=z} log(q-2) + S log(1 - rho),
         rho = 1 / (L prod_{q<=z} (1-1/q)). Si cerca il minimo L con max_z F > 0.

La parte 3 è una stima euristica: dipende da Hardy-Littlewood per le coppie
gemelle in progressione e dall'indipendenza del modello. Le parti 1 e 2 sono
conteggi (esatti nella parte 1).

Uso: python soglia_modello_raffinato.py
"""

import hashlib
import json
import math
import platform
import sys
import time
from pathlib import Path

import numpy as np

GAMMA = 0.57721566490153286061
EG = math.exp(GAMMA)
C2 = 0.66016181584686957393
TABLE = 10**7
T_SMOOTH = 1e7

# ---------------------------------------------------------------- tables up to 10^7

_s = np.ones(TABLE + 1, dtype=bool)
_s[:2] = False
for _i in range(2, math.isqrt(TABLE) + 1):
    if _s[_i]:
        _s[_i * _i :: _i] = False
PRIMES = np.nonzero(_s)[0]
PI = np.cumsum(_s, dtype=np.int64)
PI_MOD3 = {r: np.cumsum(_s & (np.arange(TABLE + 1) % 3 == r), dtype=np.int64) for r in (1, 2)}
LOG_MERTENS = np.cumsum(np.log1p(-1.0 / PRIMES))          # sum_{q <= p_k} log(1 - 1/q)
_q5 = PRIMES[PRIMES >= 5].astype(float)
THETA_STAR = np.concatenate(([0.0, 0.0], np.cumsum(np.log(_q5 - 2))))  # aligned with PRIMES index
del _s, _q5


def prime_index(z):
    """Number of primes <= z (z <= TABLE)."""
    return int(PI[int(z)])


def log_mertens(z):
    """log prod_{q <= z} (1 - 1/q); exact for z <= 10^7, Mertens beyond."""
    if z <= TABLE:
        return float(LOG_MERTENS[prime_index(z) - 1])
    return -GAMMA - math.log(math.log(z))


def theta_star(z):
    """sum_{5 <= q <= z} log(q - 2)."""
    if z <= TABLE:
        return float(THETA_STAR[prime_index(z) - 1])
    base = float(THETA_STAR[-1])
    return base + (z - TABLE) - 2 * (math.log(math.log(z)) - math.log(math.log(TABLE)))


def largest_prime_at_most(x):
    x = int(x)
    if x <= TABLE:
        return int(PRIMES[prime_index(x) - 1])
    raise ValueError


# ---------------------------------------------------------------- part 1: exact counts

def base_alive(y):
    """Window positions 1 <= n <= y with 2p + n coprime to 6 (2p = 4 mod 6)."""
    alive = np.zeros(y + 1, dtype=bool)
    alive[1::2] = True
    alive[2::3] = False
    return alive


def exact_ratio_G(y, z):
    alive = base_alive(y)
    for q in PRIMES[(PRIMES >= 5) & (PRIMES <= z)]:
        alive[1::q] = False
    S = int(alive.sum())
    return S, S / (y * math.exp(log_mertens(z)))


def exact_ratio_W(y, z):
    idx = np.nonzero(base_alive(y))[0].astype(np.int64)
    for q in PRIMES[(PRIMES >= 5) & (PRIMES <= z)]:
        q = int(q)
        res = idx % q
        counts = np.bincount(res, minlength=q).astype(np.int64)
        counts[0] = -1
        counts[4] = -1
        c = int(np.argmax(counts))
        idx = idx[res != c]
    S = int(idx.size)
    return S, S / (y * math.exp(log_mertens(z)))


def F_value(L, z, S, y):
    """log of the expected number of counterexamples with M in [e^L, 2e^L] (Granville model)."""
    lm = log_mertens(z)
    rho = math.exp(-lm) / L
    return math.log(C2) + L - 2 * math.log(L) - theta_star(z) + S * math.log1p(-rho)


# ---------------------------------------------------------------- part 2: li-based counts

def li(x):
    lx = math.log(x)
    if lx < 40:
        s, term, inner = 0.0, 1.0, 0.0
        for n in range(1, 400):
            term *= lx / n
            if n % 2 == 1:
                inner += 1.0 / n
            t = (-1) ** (n - 1) * term / 2 ** (n - 1) * inner
            s += t
            if n > 2 * lx and abs(t) < 1e-17 * abs(s):
                break
        return GAMMA + math.log(lx) + math.sqrt(x) * s
    s, term = 1.0, 1.0
    for k in range(1, 1000):
        new = term * k / lx
        if new > term:
            break
        term = new
        s += term
    return x / lx * s


def P(x):
    if x < 2:
        return 0.0
    if x <= TABLE:
        return float(PI[int(x)])
    return li(x) - 0.5 * li(math.sqrt(x))


def P3(x, r):
    """Primes <= x congruent to r mod 3 (r = 1, 2)."""
    if x <= TABLE:
        return float(PI_MOD3[r][int(x)])
    return 0.5 * (P(x) - 1)


_GX, _GW = np.polynomial.legendre.leggauss(32)


def semiprimes(t, z):
    """#{q1 <= q2 primes > z : q1 q2 <= t}."""
    if t <= z * z:
        return 0.0
    root = math.isqrt(int(t))
    if root <= TABLE and PI[root] - PI[min(int(z), root)] <= 3000:
        qs = PRIMES[(PRIMES > z) & (PRIMES <= root)]
        return float(sum(P(t / q) - P(q) + 1 for q in qs.tolist()))
    lo, hi = math.log(z), 0.5 * math.log(t)
    mid, half = 0.5 * (lo + hi), 0.5 * (hi - lo)
    acc = 0.0
    for x, w in zip(_GX, _GW):
        v = mid + half * x
        s = math.exp(v)
        acc += w * (P(t / s) - P(s) + 1) / v * s
    return acc * half


def approx_S_G(L, z):
    """S_G(y, z) for y = L^2, z < y < z^3."""
    y = L * L
    Pz = P(z)
    S = 0.0
    a = 1
    while 2.0**a <= y:
        b = 0
        while 2.0**a * 3.0**b <= y:
            if 2.0**a * 3.0**b > T_SMOOTH:
                S += 1 if (b > 0 or a % 2 == 1) else 0
                b += 1
                continue
            t = y / (2.0**a * 3.0**b)
            if b > 0:
                S += 1 + (P(t) - Pz if t > z else 0.0) + semiprimes(t, z)
            else:
                r = 1 if a % 2 == 1 else 2  # need 2^a r = 2 (mod 3)
                rough = (P3(t, r) - P3(z, r) if t > z else 0.0) + 0.5 * semiprimes(t, z)
                S += (1 if a % 2 == 1 else 0) + rough
            b += 1
        a += 1
    return S


def approx_ratio_G(L, z):
    return approx_S_G(L, z) / (L * L * math.exp(log_mertens(z)))


def best_F_G(L):
    """Golden-section search of max over z = L^e, 2/3 < e <= 1, of F for class G."""
    def f(e):
        z = L**e
        return F_value(L, z, approx_S_G(L, z), L * L)

    lo, hi = 2 / 3 + 1e-3, 1.0
    g = (math.sqrt(5) - 1) / 2
    c, d = hi - g * (hi - lo), lo + g * (hi - lo)
    fc, fd = f(c), f(d)
    for _ in range(24):
        if fc > fd:
            hi, d, fd = d, c, fc
            c = hi - g * (hi - lo)
            fc = f(c)
        else:
            lo, c, fc = c, d, fd
            d = lo + g * (hi - lo)
            fd = f(d)
    e = 0.5 * (lo + hi)
    z = L**e
    return {"log10_L": math.log10(L), "esponente_z": e, "u": 2 / e, "z": z,
            "rapporto_G": approx_ratio_G(L, z), "F_max": f(e)}


def omega(u):
    if 1 <= u <= 2:
        return 1 / u
    if 2 < u <= 3:
        return (1 + math.log(u - 1)) / u
    raise ValueError


# ---------------------------------------------------------------- main

def main():
    t0 = time.time()
    log = lambda m: print(f"[{time.time() - t0:7.1f}s] {m}", flush=True)
    out = {"descrizione": __doc__.splitlines()[0]}

    # Part 1
    rows = []
    for L, label in [(60 * math.log(10), "10^60"), (100 * math.log(10), "10^100"),
                     (1000.0, "e^1000"), (3000.0, "e^3000"), (10000.0, "e^10000")]:
        y = math.ceil(L * L)
        for u in (2.0, 2.25, 2.5, 2.75):
            z = largest_prime_at_most(L ** (2 / u))
            uz = math.log(y) / math.log(z)
            S_G, r_G = exact_ratio_G(y, z)
            row = {"M_circa": label, "L": L, "y": y, "z": z, "u": uz,
                   "S_G": S_G, "r_G": r_G, "limite_e^g_omega": EG * omega(uz),
                   "F_G": F_value(L, z, S_G, y)}
            if y <= 10**7 or (y <= 10**8 and u >= 2.5):
                S_W, r_W = exact_ratio_W(y, z)
                row |= {"S_W": S_W, "r_W": r_W, "F_W": F_value(L, z, S_W, y)}
            rows.append(row)
            log(f"esatto {label} u={uz:.3f} z={z}: r_G={r_G:.4f}" +
                (f" r_W={row['r_W']:.4f} F_W={row['F_W']:.1f}" if "r_W" in row else "") +
                f" F_G={row['F_G']:.1f}")
    out["parte_1_esatta"] = rows

    # Part 2: validation and the large-L trend at u close to 2
    val = []
    for r in rows:
        if r["L"] >= 3000:
            a = approx_ratio_G(r["L"], r["z"])
            val.append({"L": r["L"], "z": r["z"], "u": r["u"], "r_G_esatto": r["r_G"], "r_G_approssimato": a})
            log(f"convalida L={r['L']:.0f} u={r['u']:.3f}: esatto {r['r_G']:.5f}, approssimato {a:.5f}")
    out["parte_2_convalida"] = val
    trend = []
    for e10 in (4, 5, 6, 8, 10, 13, 16, 20, 30):
        L = 10.0**e10
        z = L if L > TABLE else largest_prime_at_most(L)
        trend.append({"log10_L": e10, "u": 2 * math.log(L) / math.log(z), "r_G": approx_ratio_G(L, z)})
        log(f"tendenza L=10^{e10}: r_G = {trend[-1]['r_G']:.4f} (limite {EG / 2:.4f})")
    out["parte_2_tendenza_u_2"] = trend

    # Part 3: threshold for class G
    scan = []
    for k in range(16, 45):
        L = 10.0 ** (k / 4)
        scan.append(best_F_G(L))
        s = scan[-1]
        log(f"soglia L=10^{s['log10_L']:.2f}: max F = {s['F_max']:.4g} a u = {s['u']:.3f}, r_G = {s['rapporto_G']:.4f}")
    out["parte_3_scansione_G"] = scan
    crossing = None
    for a, b in zip(scan, scan[1:]):
        if a["F_max"] <= 0 < b["F_max"]:
            w = -a["F_max"] / (b["F_max"] - a["F_max"])
            crossing = a["log10_L"] + w * (b["log10_L"] - a["log10_L"])
            break
    out["parte_3_soglia_log10_L"] = crossing
    if crossing is not None:
        log(f"soglia stimata: log M circa 10^{crossing:.2f}, cioè M con circa "
            f"{10**crossing / math.log(10):.3g} cifre decimali")
    out["esponente_asintotico_u_2"] = 1 - EG / 2
    out["python"] = sys.version
    out["numpy"] = np.__version__
    out["piattaforma"] = platform.platform()
    out["sha256_script"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out["secondi"] = round(time.time() - t0, 1)
    Path("risultati_soglia_modello.json").write_text(json.dumps(out, indent=1, ensure_ascii=False), encoding="utf-8")
    log("scritto risultati_soglia_modello.json")


if __name__ == "__main__":
    main()
