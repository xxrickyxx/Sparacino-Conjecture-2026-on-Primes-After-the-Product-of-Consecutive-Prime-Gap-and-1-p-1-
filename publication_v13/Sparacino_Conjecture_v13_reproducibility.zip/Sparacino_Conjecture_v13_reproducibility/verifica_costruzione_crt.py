"""Certifica la parte algebrica finita della costruzione CRT della nota di ricerca.

La tupla piccola serve per verificare le congruenze: non si applica il teorema di
Maynard a questa tupla, ne si afferma che tutte le sue forme siano prime.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path


def prime(n):
    return n >= 2 and all(n%d for d in range(2,math.isqrt(n)+1))


def next_prime(n):
    n += 1
    while not prime(n):
        n += 1
    return n


def main():
    offsets = [0,2,6]
    H = 10
    diameter = offsets[-1]
    residue, modulus = 1,2
    current_prime = 100
    conditions = []

    def append_condition(wanted,q,metadata):
        nonlocal residue,modulus
        step = ((wanted-residue)*pow(modulus,-1,q))%q
        residue += modulus*step
        modulus *= q
        assert residue%q == wanted%q
        assert all((residue+h)%q != 0 for h in offsets)
        conditions.append(dict(metadata,prime=q,residue=wanted%q))

    for j in range(0,diameter+1,2):
        if j in offsets:
            continue
        current_prime = next_prime(current_prime)
        append_condition(-j,current_prime,{"kind":"interior_composite","j":j})

    for i,a in enumerate(offsets):
        for b in offsets[i+1:]:
            d = b-a
            for s in range(1,H+1):
                if math.gcd(d,s)>1:
                    continue
                current_prime=next_prime(max(current_prime,d*diameter+H))
                wanted=-a-s*pow(d,-1,current_prime)
                append_condition(wanted,current_prime,{"kind":"target_composite","a":a,"d":d,"s":s})

    for condition in conditions:
        assert residue%condition["prime"] == condition["residue"]
    for ell in (2,3):
        assert len({(-h)%ell for h in offsets}) < ell
    # Per ell > 3 una tupla di tre elementi non puo coprire tutti i residui;
    # per ell|modulus tutte le forme sono gia coprime, come verificato sopra.
    for n in range(1,6):
        base=residue+modulus*n
        assert base%2 == 1
        for j in range(diameter+1):
            if j in offsets:
                continue
            q=2 if j%2 else next(c["prime"] for c in conditions
                                            if c["kind"]=="interior_composite" and c["j"]==j)
            assert (base+j)%q==0 and base+j>q
        for i,a in enumerate(offsets):
            for b in offsets[i+1:]:
                d=b-a
                for s in range(1,H+1):
                    q=math.gcd(d,s)
                    if q==1:
                        q=next(c["prime"] for c in conditions
                               if c["kind"]=="target_composite" and (c["a"],c["d"],c["s"])==(a,d,s))
                    target=d*(base+a)+s
                    assert target%q==0 and target>q
    result={"offsets":offsets,"H":H,"A":str(residue),"Q":str(modulus),
            "conditions":conditions,"tested_parameters_n":[1,2,3,4,5],
            "status":"Finite CRT algebra verified. Small tuple does not certify the Maynard step.",
            "script_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    Path("certificato_costruzione_crt.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(f"Congruenze verificate: {len(conditions)}; cifre del modulo: {len(str(modulus))}")
    print("Admissibilita delle forme e compositezza forzata verificate.")


if __name__=="__main__":
    main()
