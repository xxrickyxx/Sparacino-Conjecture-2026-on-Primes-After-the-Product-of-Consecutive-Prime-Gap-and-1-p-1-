"""Audit delle aggiunte e verifica finita della costruzione CRT con precrivello.

La costruzione dimostrativa usa {0,2,6}: verifica l'algebra, non applica
Maynard a una tupla di tre elementi. I ricontrolli a 60/100 cifre producono
primi probabili, non certificati di primalita.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import random
import statistics
import time
from decimal import Decimal, ROUND_CEILING, localcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SEED = 2026102507


def primes_up_to(n):
    s = bytearray(b"\x01") * (n + 1)
    s[:2] = b"\x00\x00"
    for q in range(2, math.isqrt(n) + 1):
        if s[q]:
            s[q*q::q] = b"\x00" * len(range(q*q, n + 1, q))
    return [q for q in range(2, n + 1) if s[q]]


def crt(conditions):
    a, modulus = 0, 1
    for q, residue in conditions.items():
        a += modulus * ((residue - a) * pow(modulus, -1, q) % q)
        modulus *= q
    assert all(a % q == residue % q for q, residue in conditions.items())
    return a, modulus


def crt_with_presieve(H, rng):
    offsets, cutoff = [0, 2, 6], 23
    pairs = list(itertools.combinations(offsets, 2))
    primes = primes_up_to(max(10000, H * 10))
    small = [q for q in primes if q <= H]
    fixed = {q: next(a for a in range(q) if all((a+h) % q for h in offsets))
             for q in small if q <= cutoff}
    fixed[11] = -4 % 11  # unica posizione interna pari fuori dalla tupla
    allowed = {q: [a for a in range(q) if all((a+h) % q for h in offsets)]
               for q in small if q > cutoff}
    targets = [(a, b-a, s) for a, b in pairs for s in range(1, H+1)
               if math.gcd(b-a, s) == 1]

    def survivors(conditions):
        return [(a,d,s) for a,d,s in targets
                if all((d*(residue+a)+s) % q for q,residue in conditions.items())]

    best = None
    for _ in range(24):
        choices = fixed | {q: rng.choice(residues) for q,residues in allowed.items()}
        remaining = survivors(choices)
        if best is None or len(remaining) < len(best[1]):
            best = choices, remaining
    conditions, remaining = best
    new_primes = iter(q for q in primes if q > H + offsets[-1]**2)
    target_witnesses = {}
    for a,d,s in remaining:
        q = next(new_primes)
        conditions[q] = (-a - s * pow(d, -1, q)) % q
        assert all((conditions[q]+h) % q for h in offsets)
        target_witnesses[(a,d,s)] = q
    residue, modulus = crt(conditions)
    base = residue + modulus
    assert all(math.gcd(base+h, modulus) == 1 for h in offsets)
    assert all((base+j) % (2 if j % 2 else 11) == 0 for j in (1,3,4,5))
    for a,b in pairs:
        d = b-a
        for s in range(1,H+1):
            target = d*(base+a)+s
            g = math.gcd(d,s)
            if g > 1:
                witness = g
            else:
                witness = next(q for q in small if target % q == 0) if (a,d,s) not in target_witnesses else target_witnesses[(a,d,s)]
            assert 1 < witness < target and target % witness == 0
    return {"H": H, "offsets": offsets, "tentativi": 24,
            "bersagli_coprimi_iniziali": len(targets),
            "bersagli_dopo_precrivello": len(remaining),
            "nuovi_primi": len(target_witnesses),
            "log_Q_su_H": math.log(modulus)/H,
            "A": str(residue), "Q": str(modulus),
            "congruenze": [[q, a] for q,a in conditions.items()],
            "tutti_bersagli_composti": True,
            "nota": "Tupla dimostrativa; nessuna affermazione di primalita degli estremi."}


def probable_prime(n, rng, small_primes):
    if n < 2:
        return False
    for q in small_primes:
        if n % q == 0:
            return n == q
    d, s = n-1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in [2, 3] + [rng.randrange(2, n-1) for _ in range(32)]:
        t = pow(a, d, n)
        if t in (1,n-1):
            continue
        for _ in range(s-1):
            t = t*t % n
            if t == n-1:
                break
        else:
            return False
    return True


def count_positions(M, N, primes):
    mask = bytearray(b"\x01") * (N+1)
    mask[0] = 0
    for q in primes:
        start = (-M) % q or q
        if start <= N:
            mask[start::q] = b"\x00" * len(range(start,N+1,q))
    return mask


def audit_new_data(rng):
    data = json.loads((ROOT/'risultati_classi_residue.json').read_text(encoding='utf-8'))
    prime_list = primes_up_to(5000)
    hash_checks = {}
    for script, output in [('esperimento_classi_residue.py','risultati_classi_residue.json'),
                           ('soglia_modello_raffinato.py','risultati_soglia_modello.json')]:
        report = json.loads((ROOT/output).read_text(encoding='utf-8'))
        hash_checks[script] = hashlib.sha256((ROOT/script).read_bytes()).hexdigest() == report['sha256_script']
    checks, recounts = [], []
    for scale in data['scale']:
        z = scale['z']
        pq = [q for q in prime_list if q <= z]
        theta = math.prod(1-1/q for q in pq)
        for group, rows in scale['campioni'].items():
            for row in rows:
                M, N = int(row['M']), row['N']
                with localcontext() as ctx:
                    ctx.prec = 90
                    L = Decimal(M).ln()
                    assert N == int((L*L).to_integral_value(rounding=ROUND_CEILING))
                sz = sum(count_positions(M,N,pq))
                assert sz == row['S_z']
                assert math.isclose(sz/theta/float(L),row['lambda_z'],rel_tol=2e-14)
            expected = scale['riepilogo'][group]
            assert math.isclose(statistics.fmean(r['primi'] for r in rows), expected['media_primi'])
            assert math.isclose(statistics.stdev(r['primi'] for r in rows)/math.sqrt(len(rows)),expected['errore_std'])
            checks.append({"scala": scale['esponente'], "gruppo": group, "finestre": len(rows),
                           "lunghezze_residui_statistiche_coerenti": True})
            selected = {rng.randrange(len(rows)), max(range(len(rows)),key=lambda i: rows[i]['K']/rows[i]['N'])}
            for idx in sorted(selected):
                row = rows[idx]
                M, N = int(row['M']), row['N']
                mask = count_positions(M,N,prime_list)
                count, first = 0, None
                for h in range(1,N+1):
                    if mask[h] and probable_prime(M+h,rng,[]):
                        count += 1
                        first = h if first is None else first
                assert (count,first) == (row['primi'],row['K'])
                if group in ('G','W','R','B'):
                    p = int(row['p'])
                    assert M == 2*p
                    assert probable_prime(p,rng,prime_list) and probable_prime(p+2,rng,prime_list)
                recounts.append({"scala":scale['esponente'], "gruppo":group, "indice":idx,
                                 "M":str(M), "N":N, "conteggio":count, "K":first,
                                 "coincide":True})
            print(f"Ricontrollato gruppo {group}, scala 10^{scale['esponente']}",flush=True)
    return {"hash_coerenti":hash_checks,"controlli_tutti_dati":checks,
            "finestre_ricontate_con_32_basi_aggiuntive":recounts,
            "avvertenza":"Test di primalita probabile; non sono certificati."}


def main():
    started = time.monotonic()
    rng = random.Random(SEED)
    out = {"seme":SEED,"audit_aggiunte":audit_new_data(rng),
           "costruzioni_CRT":[crt_with_presieve(H,rng) for H in (64,256,1024)]}
    out['secondi'] = round(time.monotonic()-started,2)
    out['sha256_script'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (ROOT/'certificato_avanzamento_rigoroso.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({"secondi":out['secondi'],"finestre_ricontate":len(out['audit_aggiunte']['finestre_ricontate_con_32_basi_aggiuntive']),
                      "CRT":[{key:r[key] for key in ('H','bersagli_coprimi_iniziali','nuovi_primi','log_Q_su_H')} for r in out['costruzioni_CRT']]},indent=2))


if __name__ == '__main__':
    main()
