"""Certificati elementari per le criticita individuate nel record Zenodo 21973485."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np


def least_factor(n: int) -> int:
    if n < 2:
        return 1
    if n % 2 == 0:
        return 2
    for q in range(3, math.isqrt(n) + 1, 2):
        if n % q == 0:
            return q
    return n


def strong_test(n: int, a: int) -> bool:
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1
    x = pow(a, d, n)
    if x in (1, n - 1):
        return True
    for _ in range(1, s):
        x = x * x % n
        if x == n - 1:
            return True
    return False


def main():
    n = 59276361075595573263446330101
    u, v = 172157429516701, 344314859033401
    bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    tests = {str(a): strong_test(n, a) for a in bases}
    assert u * v == n and 1 < u < n and all(tests.values()) and n < 10**30

    p, p2, d = 1005371, 1005373, 2
    m, window, first = p * d, 211, 139
    assert least_factor(p) == p and least_factor(p2) == p2
    assert least_factor(m + first) == m + first
    factors = []
    for k in range(1, first):
        q = least_factor(m + k)
        assert 1 < q < m + k
        factors.append({"k": k, "n": m+k, "divisor": q, "quotient": (m+k)//q})
    assert math.ceil(math.log(m)**2) == window

    original = Path("fonti_originali")
    with np.load(original / "statistiche_congettura_10000000000000.npz", allow_pickle=False) as archive:
        hist = archive["hist_k"]
        original_stats = {"pairs": int(hist.sum()), "max_observed_k": int(np.flatnonzero(hist)[-1]),
                          "mean_k": float((np.arange(len(hist))*hist).sum()/hist.sum())}
    source_files = ["test_final.py", "testcongetturadirickyv2.py", "risultato_gpu_10000000000000.txt",
                    "statistiche_congettura_10000000000000.npz"]
    hashes = {name: hashlib.sha256((original/name).read_bytes()).hexdigest() for name in source_files}

    # Controllo indipendente dei risultati numerici su un campione riproducibile:
    # divisibilita per tentativi, compresi i casi con rapporto piu elevato.
    with np.load("verifica_indipendente_coppie.npz", allow_pickle=False) as data:
        rng = np.random.default_rng(20261025)
        ids = set(map(int, rng.integers(0, len(data["p1"]), size=100)))
        ids.update(map(int, np.argsort(data["k"] / data["N"])[-20:]))
        for i in ids:
            a, b, mm, kk = (int(data[key][i]) for key in ("p1", "p2", "M", "k"))
            assert least_factor(a) == a and least_factor(b) == b
            assert all(least_factor(j) != j for j in range(a+1, b))
            assert least_factor(mm+kk) == mm+kk
            assert all(least_factor(j) != j for j in range(mm+1, mm+kk))
        sample_size = len(ids)

    result = {"date": "2026-10-25", "composite_passing_all_15_bases": {
        "n": str(n), "factor1": str(u), "factor2": str(v), "tests": tests,
        "base_53_result": strong_test(n, 53),
        "meaning": "Counterexample to deterministic primality claim; not to Sparacino conjecture."},
        "ratio_counterexample": {"p1": p, "p2": p2, "d": d, "M": m, "N": window,
            "first_prime": m+first, "k": first, "k_over_N": first/window,
            "composite_certificates_for_all_smaller_offsets": factors},
        "original_npz": original_stats, "source_sha256": hashes,
        "independent_trial_division_sample": sample_size}
    Path("certificati_audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("Composto che supera le 15 basi:", n, "=", u, "*", v)
    print("Caso certificato con k/N > 0.414:", p, p2, first/window)
    print("Campione ricontrollato per divisione diretta:", sample_size)
    print("Archivio originale:", original_stats)
    print("Certificati salvati in certificati_audit.json")


if __name__ == "__main__":
    main()
